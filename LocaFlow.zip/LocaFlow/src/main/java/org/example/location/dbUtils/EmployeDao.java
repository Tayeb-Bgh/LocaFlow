package org.example.location.dbUtils;

import org.example.location.models.Client;
import org.example.location.models.Contrat;
import org.example.location.models.Employe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeDao {

    public static List<Employe> fetchAllEmployees() {
        List<Employe> employees = new ArrayList<>();

        String query = """
        SELECT idEmp, nomEmp, prenomEmp, telEmp, adressEmp, permissionEmp 
        FROM employe 
        WHERE supprimerEmp = 0
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Employe employe = new Employe();

                employe.setIdEmp(resultSet.getInt("idEmp"));
                employe.setNomEmp(resultSet.getString("nomEmp"));
                employe.setPrenomEmp(resultSet.getString("prenomEmp"));
                employe.setTelEmp(resultSet.getInt("telEmp"));
                employe.setAdressEmp(resultSet.getString("adressEmp"));
                employe.setPermissionEmp(resultSet.getBoolean("permissionEmp"));

                employees.add(employe);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employees;
    }

    public static void addEmploye(Employe newEmploye) {
        String query = "INSERT INTO employe(nomEmp, prenomEmp, telEmp, adressEmp, ccpEmp, sexeEmp, dateNaissEmp, permissionEmp, usernameEmp, mdpEmp, supprimerEmp) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection connection = DBUtils.getConnection();
            PreparedStatement psInsert = connection.prepareStatement(query);

            psInsert.setString(1, newEmploye.getNomEmp());
            psInsert.setString(2, newEmploye.getPrenomEmp());
            psInsert.setInt(3, newEmploye.getTelEmp());
            psInsert.setString(4, newEmploye.getAdressEmp());
            psInsert.setInt(5, newEmploye.getCcpEmp());
            psInsert.setString(6, String.valueOf(newEmploye.getSexeEmp()));
            psInsert.setDate(7, Date.valueOf(newEmploye.getDateNaissEmp()));
            psInsert.setBoolean(8, newEmploye.getPermissionEmp());
            psInsert.setString(9, newEmploye.getUsernameEmp());
            psInsert.setString(10, newEmploye.getMdpEmp());
            psInsert.setBoolean(11, newEmploye.getSupprimerEmp() != null ? newEmploye.getSupprimerEmp() : false);

            int rs = psInsert.executeUpdate();
            if (rs > 0) {
                System.out.println("Insertion réussie de l'employé.");
            } else {
                System.out.println("Échec de l'insertion de l'employé.");
            }

            psInsert.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion de l'employé", e);
        }
    }
    public static boolean deleteEmploye(int idEmp) {
        String query = "UPDATE employe SET supprimerEmp = 1 WHERE idEmp = ?";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idEmp);
            return statement.executeUpdate() > 0; // Retourne true si la suppression a réussi

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Employe getEmployeDetails(int idEmp) {
        Employe employe = new Employe();
        String query = """
        SELECT idEmp, 
               nomEmp, 
               prenomEmp, 
               telEmp, 
               adressEmp, 
               ccpEmp, 
               sexeEmp, 
               dateNaissEmp, 
               permissionEmp, 
               usernameEmp, 
               mdpEmp
        FROM employe
        WHERE idEmp = ? AND supprimerEmp = 0
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idEmp);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                employe.setIdEmp(resultSet.getInt("idEmp"));
                employe.setNomEmp(resultSet.getString("nomEmp"));
                employe.setPrenomEmp(resultSet.getString("prenomEmp"));
                employe.setTelEmp(resultSet.getInt("telEmp"));
                employe.setAdressEmp(resultSet.getString("adressEmp"));
                employe.setCcpEmp(resultSet.getInt("ccpEmp"));
                employe.setSexeEmp(resultSet.getString("sexeEmp").charAt(0));
                employe.setDateNaissEmp(resultSet.getDate("dateNaissEmp").toLocalDate());
                employe.setPermissionEmp(resultSet.getBoolean("permissionEmp"));
                employe.setUsernameEmp(resultSet.getString("usernameEmp"));
                employe.setMdpEmp(resultSet.getString("mdpEmp"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erreur lors de la récupération des détails de l'employé", e);
        }

        return employe;
    }



    public static boolean updateEmploye(Employe employe) {
        String query = """
        UPDATE employe
        SET nomEmp = ?, prenomEmp = ?, telEmp = ?, adressEmp = ?, ccpEmp = ?, 
            sexeEmp = ?, dateNaissEmp = ?, permissionEmp = ?, usernameEmp = ?, mdpEmp = ?
        WHERE idEmp = ?
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement psUpdate = connection.prepareStatement(query)) {

            psUpdate.setString(1, employe.getNomEmp());
            psUpdate.setString(2, employe.getPrenomEmp());
            psUpdate.setInt(3, employe.getTelEmp());
            psUpdate.setString(4, employe.getAdressEmp());
            psUpdate.setInt(5, employe.getCcpEmp());
            psUpdate.setString(6, String.valueOf(employe.getSexeEmp()));
            psUpdate.setDate(7, Date.valueOf(employe.getDateNaissEmp()));
            psUpdate.setBoolean(8, employe.getPermissionEmp());
            psUpdate.setString(9, employe.getUsernameEmp());
            psUpdate.setString(10, employe.getMdpEmp());
            psUpdate.setInt(11, employe.getIdEmp());

            return psUpdate.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Contrat> getContratsByEmployeId(int employeId) {
        List<Contrat> contrats = new ArrayList<>();
        String query = "SELECT c.idContrat, c.debContrat, c.finContrat, cl.nomClt, cl.prenomClt " +
                "FROM contrat c " +
                "JOIN client cl ON c.idClt = cl.idClt " +
                "WHERE c.idEmp = ?";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, employeId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Contrat contrat = new Contrat();
                contrat.setIdContrat(rs.getInt("idContrat"));
                contrat.setDebContrat(rs.getTimestamp("debContrat").toLocalDateTime());
                contrat.setFinContrat(rs.getTimestamp("finContrat").toLocalDateTime());

                Client client = new Client();
                client.setNomClt(rs.getString("nomClt"));
                client.setPrenomClt(rs.getString("prenomClt"));
                contrat.setClient(client);

                contrats.add(contrat);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contrats;
    }

}
