package org.example.location.dbUtils;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.location.models.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class VoitureDao {

    public static ObservableList<Vehicule> fetchAllVehicles() {
        ObservableList<Vehicule> vehicles = FXCollections.observableArrayList();


        String query = """
        SELECT v.idVeh,
               v.matriculeVeh,
               v.modeleVeh,
               v.marqueVeh,
               v.numChassisVeh,
               v.couleurVeh,
               v.carteGriseVeh,
               v.energieVeh,
               v.supprimerVeh,
               v.kilometrage,
               COALESCE(
                   (SELECT statutContrat
                    FROM contrat
                    WHERE contrat.idVeh = v.idVeh AND contrat.supprimerCtr = 0
                    ORDER BY idContrat DESC
                    LIMIT 1),
                   -1
               ) AS dernierStatutContrat,
               (SELECT MAX(finMaintenance)
                FROM maintenance
                WHERE idVeh = v.idVeh
                  AND finMaintenance > CURDATE()) AS derniereFinMaintenance,
               s.assuranceExp AS expirationAssurance,
               s.controleTechExp AS expirationControleTech,
               s.vidangeExp AS vidangeKm
        FROM vehicule v
        LEFT JOIN suivie s ON s.idVeh = v.idVeh
        WHERE v.supprimerVeh = 0;
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Vehicule vehicule = new Vehicule();
                Suivie suivie = new Suivie();

                // Remplissage des informations de base du véhicule
                vehicule.setIdVeh(resultSet.getInt("idVeh"));
                vehicule.setModeleVeh(resultSet.getString("modeleVeh"));
                vehicule.setMarqueVeh(resultSet.getString("marqueVeh"));
                vehicule.setEnergieVeh(resultSet.getString("energieVeh"));
                vehicule.setSupprimerVeh(resultSet.getBoolean("supprimerVeh"));

                // Informations spécifiques au suivi
                suivie.setAssuranceExp(resultSet.getDate("expirationAssurance") != null ? resultSet.getDate("expirationAssurance").toLocalDate() : null);
                suivie.setControleTechExp(resultSet.getDate("expirationControleTech") != null ? resultSet.getDate("expirationControleTech").toLocalDate() : null);
                suivie.setVidangeExp(resultSet.getInt("vidangeKm"));

                // Calcul du statut du véhicule
                int dernierStatutContrat = resultSet.getInt("dernierStatutContrat");
                Date derniereFinMaintenance = resultSet.getDate("derniereFinMaintenance");
                System.out.println(suivie.getAssuranceExp());
                if (dernierStatutContrat == 0) {
                    vehicule.setStatutVeh("En Location");
                } else if (derniereFinMaintenance == null || derniereFinMaintenance.before(new Date())) {
                    vehicule.setStatutVeh("Disponible");
                } else {
                    vehicule.setStatutVeh("En Maintenance");
                }
                vehicule.ajouterSuivie(suivie);
                // Ajout du suivi au véhicule
                vehicles.add(vehicule);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehicles;
    }



    public static boolean addVehicle(Vehicule vehicule) {
        String vehicleQuery = """
        INSERT INTO vehicule (marqueVeh, modeleVeh, matriculeVeh, couleurVeh, numChassisVeh, carteGriseVeh, energieVeh,kilometrage, supprimerVeh)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?,0)
    """;

        String suivieQuery = """
        INSERT INTO suivie (idVeh, assuranceExp, controleTechExp, vidangeExp)
        VALUES (?, ?, ?, ?)
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement vehicleStatement = connection.prepareStatement(vehicleQuery, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement suivieStatement = connection.prepareStatement(suivieQuery)) {

            // Insérer le véhicule
            vehicleStatement.setString(1, vehicule.getMarqueVeh());
            vehicleStatement.setString(2, vehicule.getModeleVeh());
            vehicleStatement.setString(3, vehicule.getMatriculeVeh());
            vehicleStatement.setString(4, vehicule.getCouleurVeh());
            vehicleStatement.setString(5, vehicule.getNumChassisVeh());
            vehicleStatement.setString(6, vehicule.getCarteGriseVeh());
            vehicleStatement.setString(7, vehicule.getEnergieVeh());
            vehicleStatement.setInt(8, vehicule.getKilometrage());
            vehicleStatement.executeUpdate();

            // Récupérer l'ID généré
            ResultSet generatedKeys = vehicleStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int vehiculeId = generatedKeys.getInt(1);

                // Insérer le suivi
                if (!vehicule.getSuivies().isEmpty()) {
                    Suivie suivie = vehicule.getSuivies().get(0);
                    suivieStatement.setInt(1, vehiculeId);
                    suivieStatement.setDate(2, suivie.getAssuranceExp() != null ? java.sql.Date.valueOf(suivie.getAssuranceExp()) : null);
                    suivieStatement.setDate(3, suivie.getControleTechExp() != null ? java.sql.Date.valueOf(suivie.getControleTechExp()) : null);
                    suivieStatement.setInt(4, suivie.getVidangeExp());
                    suivieStatement.executeUpdate();
                }
            }

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updateVehicle(Vehicule vehicule) {
        Connection connection = null;
        PreparedStatement statementVehicule = null;
        PreparedStatement statementSuivie = null;
        boolean success = false;

        try {
            connection = DBUtils.getConnection();
            connection.setAutoCommit(false);


            String updateVehiculeQuery = """
            UPDATE vehicule
            SET matriculeVeh = ?, 
                modeleVeh = ?, 
                marqueVeh = ?, 
                numChassisVeh = ?, 
                couleurVeh = ?, 
                carteGriseVeh = ?, 
                energieVeh = ?
            WHERE idVeh = ?
        """;

            statementVehicule = connection.prepareStatement(updateVehiculeQuery);
            statementVehicule.setString(1, vehicule.getMatriculeVeh());
            statementVehicule.setString(2, vehicule.getModeleVeh());
            statementVehicule.setString(3, vehicule.getMarqueVeh());
            statementVehicule.setString(4, vehicule.getNumChassisVeh());
            statementVehicule.setString(5, vehicule.getCouleurVeh());
            statementVehicule.setString(6, vehicule.getCarteGriseVeh());
            statementVehicule.setString(7, vehicule.getEnergieVeh());
            statementVehicule.setInt(8, vehicule.getIdVeh());

            int vehiculeUpdatedRows = statementVehicule.executeUpdate();


            if (!vehicule.getSuivies().isEmpty()) {
                Suivie suivie = vehicule.getSuivies().get(0);

                String updateSuivieQuery = """
                UPDATE suivie
                SET controleTechExp = ?, 
                    assuranceExp = ?, 
                    vidangeExp = ?
                WHERE idVeh = ?
            """;

                statementSuivie = connection.prepareStatement(updateSuivieQuery);
                statementSuivie.setDate(1, suivie.getControleTechExp() != null ? java.sql.Date.valueOf(suivie.getControleTechExp()) : null);
                statementSuivie.setDate(2, suivie.getAssuranceExp() != null ? java.sql.Date.valueOf(suivie.getAssuranceExp()) : null);
                statementSuivie.setInt(3, suivie.getVidangeExp());
                statementSuivie.setInt(4, vehicule.getIdVeh());

                int suiviUpdatedRows = statementSuivie.executeUpdate();

                if (vehiculeUpdatedRows > 0 && suiviUpdatedRows > 0) {
                    connection.commit();
                    success = true;
                } else {
                    connection.rollback();
                }
            } else {
                connection.commit();
                success = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (connection != null) connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
        } finally {
            try {
                if (statementVehicule != null) statementVehicule.close();
                if (statementSuivie != null) statementSuivie.close();
                if (connection != null) connection.setAutoCommit(true);
                if (connection != null) connection.close();
            } catch (SQLException closeEx) {
                closeEx.printStackTrace();
            }
        }

        return success;
    }




    public static boolean deleteVehicle(int idVeh) {
        String query = "UPDATE vehicule SET supprimerVeh = 1 WHERE idVeh = ?";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idVeh);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }




    public static Vehicule getVoitureDetails(int idVeh) {
        Vehicule vehicule = new Vehicule();

        String query = """
            SELECT v.idVeh, v.matriculeVeh, v.modeleVeh, v.marqueVeh, v.numChassisVeh, 
                   v.couleurVeh, v.carteGriseVeh, v.energieVeh, v.kilometrage,
                   s.assuranceExp, s.controleTechExp, s.vidangeExp
            FROM vehicule v 
            LEFT JOIN suivie s ON v.idVeh = s.idVeh 
            WHERE v.idVeh = ?
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idVeh);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                vehicule.setIdVeh(resultSet.getInt("idVeh"));
                vehicule.setMatriculeVeh(resultSet.getString("matriculeVeh"));
                vehicule.setModeleVeh(resultSet.getString("modeleVeh"));
                vehicule.setMarqueVeh(resultSet.getString("marqueVeh"));
                vehicule.setNumChassisVeh(resultSet.getString("numChassisVeh"));
                vehicule.setCouleurVeh(resultSet.getString("couleurVeh"));
                vehicule.setCarteGriseVeh(resultSet.getString("carteGriseVeh"));
                vehicule.setEnergieVeh(resultSet.getString("energieVeh"));
                vehicule.setKilometrage(resultSet.getInt("kilometrage"));

                Suivie suivie = new Suivie();
                suivie.setAssuranceExp(resultSet.getDate("assuranceExp") != null ? resultSet.getDate("assuranceExp").toLocalDate() : null);
                suivie.setControleTechExp(resultSet.getDate("controleTechExp") != null ? resultSet.getDate("controleTechExp").toLocalDate() : null);
                suivie.setVidangeExp(resultSet.getInt("vidangeExp"));

                vehicule.ajouterSuivie(suivie);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        loadCurrentContract(idVeh, vehicule);
        loadMaintenanceHistory(idVeh, vehicule);

        return vehicule;
    }

    private static void loadCurrentContract(int idVeh, Vehicule vehicule) {
        String query = """
            SELECT c.idContrat, c.debContrat, c.finContrat, c.prixContrat, c.cautionContrat, 
                   cl.nomClt, cl.prenomClt
            FROM contrat c
            JOIN client cl ON c.idClt = cl.idClt
            WHERE c.idVeh = ? AND c.statutContrat = 0
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idVeh);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Contrat contrat = new Contrat();
                contrat.setIdContrat(resultSet.getInt("idContrat"));
                contrat.setDebContrat(resultSet.getTimestamp("debContrat").toLocalDateTime());
                contrat.setFinContrat(resultSet.getTimestamp("finContrat").toLocalDateTime());
                contrat.setPrixContrat(resultSet.getInt("prixContrat"));
                contrat.setCautionContrat(resultSet.getInt("cautionContrat"));

                Client client = new Client();
                client.setNomClt(resultSet.getString("nomClt"));
                client.setPrenomClt(resultSet.getString("prenomClt"));

                contrat.setClient(client);
                vehicule.setContratActuel(contrat);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void loadMaintenanceHistory(int idVeh, Vehicule vehicule) {
        String query = """
            SELECT idMaintenance, debMaintenance, finMaintenance, prixMaintenance
            FROM maintenance
            WHERE idVeh = ?
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idVeh);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Maintenance maintenance = new Maintenance();
                maintenance.setIdMaintenance(resultSet.getInt("idMaintenance"));
                maintenance.setDebMaintenance(resultSet.getDate("debMaintenance").toLocalDate());
                maintenance.setFinMaintenance(resultSet.getDate("finMaintenance").toLocalDate());
                maintenance.setPrixMaintenance(resultSet.getBigDecimal("prixMaintenance").intValueExact());
                vehicule.ajouterMaintenance(maintenance);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Vehicule getMaintenanceVoiture(int idVeh) {
        Vehicule voiture = null;

        String query = "SELECT v.idVeh, v.marqueVeh, v.modeleVeh, v.energieVeh, " +
                "m.idMaintenance, m.debMaintenance, m.finMaintenance, m.prixMaintenance " +
                "FROM vehicule v " +
                "INNER JOIN maintenance m ON v.idVeh = m.idVeh " +
                "WHERE v.idVeh = ? AND m.finMaintenance >= CURDATE() " +
                "ORDER BY m.finMaintenance DESC LIMIT 1";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, idVeh);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                voiture = new Vehicule();
                voiture.setIdVeh(rs.getInt("idVeh"));
                voiture.setMarqueVeh(rs.getString("marqueVeh"));
                voiture.setModeleVeh(rs.getString("modeleVeh"));
                voiture.setEnergieVeh(rs.getString("energieVeh"));

                Maintenance maintenance = new Maintenance();
                maintenance.setIdMaintenance(rs.getInt("idMaintenance"));
                maintenance.setDebMaintenance(rs.getDate("debMaintenance").toLocalDate());
                maintenance.setFinMaintenance(rs.getDate("finMaintenance").toLocalDate());
                maintenance.setPrixMaintenance(rs.getBigDecimal("prixMaintenance").intValue());

                voiture.addMaintenance(maintenance);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return voiture;
    }



    public static void addMaintenance(Maintenance maintenance) {
        String query = "INSERT INTO maintenance (idVeh, debMaintenance, finMaintenance, prixMaintenance) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, maintenance.getIdVeh());
            stmt.setDate(2, java.sql.Date.valueOf(maintenance.getDebMaintenance()));
            stmt.setDate(3, java.sql.Date.valueOf(maintenance.getFinMaintenance()));
            stmt.setDouble(4, maintenance.getPrixMaintenance());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void terminerMaintenance(int idMaintenance, LocalDate nouvelleDateFin) {
        String query = "UPDATE maintenance SET finMaintenance = ? WHERE idMaintenance = ?";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDate(1, java.sql.Date.valueOf(nouvelleDateFin));
            stmt.setInt(2, idMaintenance);

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean isVoitureEnLocation(int idVeh) {
        String query = "SELECT COUNT(*) AS count FROM contrat " +
                "WHERE idVeh = ? AND statutContrat = 0"; // 1 représente un contrat en cours

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, idVeh);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("count") > 0; // Si count > 0, la voiture est en location
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


}
