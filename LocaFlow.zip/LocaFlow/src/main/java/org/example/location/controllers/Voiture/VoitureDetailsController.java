package org.example.location.controllers.Voiture;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.location.controllers.Location.ProlongationAddController;
import org.example.location.dbUtils.LocationDao;
import org.example.location.dbUtils.VoitureDao;
import org.example.location.models.Contrat;
import org.example.location.models.Maintenance;
import org.example.location.models.Vehicule;

import java.io.IOException;
import java.time.LocalDate;

public class VoitureDetailsController {

    // Vehicle information labels
    @FXML private Label idLabel;
    @FXML private Label matriculeLabel;
    @FXML private Label marqueLabel;
    @FXML private Label modeleLabel;
    @FXML private Label chassisLabel;
    @FXML private Label couleurLabel;
    @FXML private Label carteGriseLabel;
    @FXML private Label energieLabel;
    @FXML private Label controleTechniqueLabel;
    @FXML private Label assuranceLabel;
    @FXML private Label vidangeLabel;
    @FXML private Label kilometrageLabel;

    // Tables for contract and maintenance details
    @FXML private TableView<Contrat> reservationsTable;
    @FXML private TableColumn<Contrat, Integer> idReservation;
    @FXML private TableColumn<Contrat, String> clientReservation;
    @FXML private TableColumn<Contrat, String> dateDebutReservation;
    @FXML private TableColumn<Contrat, String> dateFinReservation;
    @FXML private TableColumn<Contrat, Integer> nbJoursReservation;
    @FXML private TableColumn<Contrat, Double> prixTotalReservation;
    @FXML private TableColumn<Contrat, Double> cautionReservation;

    @FXML private TableView<Maintenance> maintenanceTable;
    @FXML private TableColumn<Maintenance, Integer> idMaintenance;
    @FXML private TableColumn<Maintenance, String> typeMaintenance;
    @FXML private TableColumn<Maintenance, String> dateDebutMaintenance;
    @FXML private TableColumn<Maintenance, String> dateFinMaintenance;
    @FXML private TableColumn<Maintenance, String> descriptionMaintenance;
    @FXML private TableColumn<Maintenance, Double> montantMaintenance;

    private Vehicule currentVoiture=new Vehicule();

    @FXML
    private void handleClose() {
        Stage stage = (Stage) idLabel.getScene().getWindow();
        stage.close();
    }

    public void setVoitureDetails(Vehicule detailedVehicule) {
        if (detailedVehicule == null) return;
        currentVoiture=detailedVehicule;
        // Set vehicle information
        idLabel.setText(String.valueOf(detailedVehicule.getIdVeh()));
        matriculeLabel.setText(detailedVehicule.getMatriculeVeh());
        marqueLabel.setText(detailedVehicule.getMarqueVeh());
        modeleLabel.setText(detailedVehicule.getModeleVeh());
        chassisLabel.setText(detailedVehicule.getNumChassisVeh());
        couleurLabel.setText(detailedVehicule.getCouleurVeh());
        carteGriseLabel.setText(detailedVehicule.getCarteGriseVeh());
        energieLabel.setText(detailedVehicule.getEnergieVeh());
        kilometrageLabel.setText(String.valueOf(detailedVehicule.getKilometrage()) + " km");


        // Set suivi information (only one Suivie is expected)
        if (!detailedVehicule.getSuivies().isEmpty()) {
            var suivie = detailedVehicule.getSuivies().get(0);
            controleTechniqueLabel.setText(suivie.getControleTechExp() != null ? suivie.getControleTechExp().toString() : "Non défini");
            assuranceLabel.setText(suivie.getAssuranceExp() != null ? suivie.getAssuranceExp().toString() : "Non défini");
            vidangeLabel.setText(suivie.getVidangeExp() > 0 ? String.valueOf(suivie.getVidangeExp()) + " km" : "Non défini");

        }


        if (detailedVehicule.getContratActuel() != null) {
            Contrat contrat = detailedVehicule.getContratActuel();
            reservationsTable.getItems().clear();
            reservationsTable.getItems().add(contrat);
        }

        if (!detailedVehicule.getMaintenances().isEmpty()) {
            maintenanceTable.getItems().clear();
            maintenanceTable.getItems().addAll(detailedVehicule.getMaintenances());
        }
    }

    @FXML
    public void initialize() {

        idReservation.setCellValueFactory(new PropertyValueFactory<>("idContrat"));
        clientReservation.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(
                        param.getValue().getClient().getNomClt() + " " + param.getValue().getClient().getPrenomClt()
                )
        );
        dateDebutReservation.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(param.getValue().getDebContrat().toLocalDate().toString())
        );
        dateFinReservation.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(param.getValue().getFinContrat().toLocalDate().toString())
        );
        nbJoursReservation.setCellValueFactory(param ->
                new javafx.beans.property.SimpleIntegerProperty(
                        (int) java.time.Duration.between(param.getValue().getDebContrat(), param.getValue().getFinContrat()).toDays()
                ).asObject()
        );
        prixTotalReservation.setCellValueFactory(new PropertyValueFactory<>("prixContrat"));
        cautionReservation.setCellValueFactory(new PropertyValueFactory<>("cautionContrat"));


        idMaintenance.setCellValueFactory(new PropertyValueFactory<>("idMaintenance"));

        dateDebutMaintenance.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(param.getValue().getDebMaintenance().toString())
        );
        dateFinMaintenance.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(param.getValue().getFinMaintenance().toString())
        );

        montantMaintenance.setCellValueFactory(new PropertyValueFactory<>("prixMaintenance"));
    }

    public void handleAddMaintenance(ActionEvent event) {
        try {

            if (VoitureDao.isVoitureEnLocation(currentVoiture.getIdVeh())) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText("Impossible d'ajouter une maintenance");
                alert.setContentText("Le véhicule est actuellement en location et ne peut pas être mis en maintenance.");
                alert.showAndWait();
                return;
            }


            Vehicule veh = VoitureDao.getMaintenanceVoiture(currentVoiture.getIdVeh());
            if (veh == null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Voiture/maintenance-add-view.fxml"));
                Scene modalScene = new Scene(loader.load(), 500, 400);

                MaintenanceAddController controller = loader.getController();
                controller.setVehId(currentVoiture.getIdVeh());

                Stage modalStage = new Stage();
                modalStage.initModality(Modality.APPLICATION_MODAL);
                modalStage.setScene(modalScene);
                modalStage.showAndWait();


            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText("Impossible d'ajouter une maintenance");
                alert.setContentText("Le véhicule est déjà en maintenance actuellement.");
                alert.showAndWait();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void handleEndMaintenance(ActionEvent event) {

        Vehicule vehicule = VoitureDao.getMaintenanceVoiture(currentVoiture.getIdVeh());

        if (vehicule != null && !vehicule.getMaintenances().isEmpty()) {

            Maintenance maintenanceEnCours = vehicule.getMaintenances().get(0);

            // Mettre à jour la date de fin de maintenance à hier
            LocalDate nouvelleDateFin = LocalDate.now().minusDays(1);

            // Appel à la DAO pour effectuer la mise à jour
            VoitureDao.terminerMaintenance(maintenanceEnCours.getIdMaintenance(), nouvelleDateFin);

            // Afficher une alerte de confirmation
            showAlert("Succès", "La maintenance a été terminée avec succès.");



        } else {
            // Afficher une alerte indiquant qu'aucune maintenance n'est en cours
            showAlert("Information", "Aucune maintenance en cours pour ce véhicule.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }



}
