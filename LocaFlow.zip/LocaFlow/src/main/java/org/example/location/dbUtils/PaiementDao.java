package org.example.location.dbUtils;

import org.example.location.models.Client;
import org.example.location.models.Contrat;
import org.example.location.models.Paiement;
import org.example.location.models.Vehicule;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PaiementDao {

    public static List<Contrat> fetchNonPayedContracts() {
        List<Contrat> contratsList = new ArrayList<>();

        String query = """
            SELECT c.idContrat, cl.nomClt, v.modeleVeh, c.debContrat, c.finContrat, 
                   c.prixContrat, c.cautionContrat, c.statutContrat, 
                   p.idPaiement, p.datePaiement, p.montantPaiement 
            FROM contrat c
            JOIN client cl ON c.idClt = cl.idClt
            JOIN vehicule v ON c.idVeh = v.idVeh
            LEFT JOIN paiement p ON p.idContrat = c.idContrat
            WHERE c.prixContrat > IFNULL((SELECT SUM(p.montantPaiement) FROM paiement p WHERE p.idContrat = c.idContrat), 0);
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            Contrat currentContrat = null;
            while (resultSet.next()) {
                int contratId = resultSet.getInt("idContrat");

                if (currentContrat == null || currentContrat.getIdContrat() != contratId) {
                    currentContrat = new Contrat();
                    currentContrat.setIdContrat(contratId);
                    currentContrat.setDebContrat(resultSet.getTimestamp("debContrat").toLocalDateTime());
                    currentContrat.setFinContrat(resultSet.getTimestamp("finContrat").toLocalDateTime());
                    currentContrat.setPrixContrat(resultSet.getDouble("prixContrat"));
                    currentContrat.setCautionContrat(resultSet.getDouble("cautionContrat"));
                    currentContrat.setStatutContrat(resultSet.getBoolean("statutContrat"));

                    Client client = new Client();
                    client.setNomClt(resultSet.getString("nomClt"));
                    currentContrat.setClient(client);

                    Vehicule vehicule = new Vehicule();
                    vehicule.setModeleVeh(resultSet.getString("modeleVeh"));
                    currentContrat.setVehicule(vehicule);

                    contratsList.add(currentContrat);
                }

                int paiementId = resultSet.getInt("idPaiement");
                if (paiementId != 0) {
                    Paiement paiement = new Paiement();
                    paiement.setIdPaiement(paiementId);
                    paiement.setDatePaiement(resultSet.getTimestamp("datePaiement").toLocalDateTime());
                    paiement.setMontantPaiement(resultSet.getInt("montantPaiement"));

                    currentContrat.getPaiements().add(paiement);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contratsList;
    }

    public static double getTotalPaiementsForContrat(int idContrat) {
        double total = 0;
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT SUM(montantPaiement) AS total FROM paiement WHERE idContrat = ?")) {
            stmt.setInt(1, idContrat);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                total = rs.getDouble("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }

    public static List<Paiement> fetchAllPaiements() {
        List<Paiement> paiements = new ArrayList<>();

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT p.idPaiement, p.datePaiement, p.montantPaiement, " +
                             "c.idContrat, cl.nomClt, v.modeleVeh " +
                             "FROM paiement p " +
                             "JOIN contrat c ON p.idContrat = c.idContrat " +
                             "JOIN client cl ON c.idClt = cl.idClt " +
                             "JOIN vehicule v ON c.idVeh = v.idVeh")) {

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Paiement paiement = new Paiement();
                paiement.setIdPaiement(rs.getInt("idPaiement"));
                paiement.setDatePaiement(rs.getTimestamp("datePaiement").toLocalDateTime());
                paiement.setMontantPaiement(rs.getInt("montantPaiement"));

                Contrat contrat = new Contrat();
                contrat.setIdContrat(rs.getInt("idContrat"));

                Client client = new Client();
                client.setNomClt(rs.getString("nomClt"));
                contrat.setClient(client);

                paiement.setContrat(contrat);
                paiements.add(paiement);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return paiements;
    }

    public static void insertPaiement(int idContrat, double montant, LocalDate date) {
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO paiement (idContrat, datePaiement, montantPaiement) VALUES (?, ?, ?)")) {
            stmt.setInt(1, idContrat);
            stmt.setDate(2, Date.valueOf(date));
            stmt.setDouble(3, montant);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erreur lors de l'insertion du paiement.");
        }
    }

    public static List<Paiement> getPaiementsByContratId(int idContrat) {
        List<Paiement> paiements = new ArrayList<>();

        String query = "SELECT p.idPaiement, p.datePaiement, p.montantPaiement, cl.nomClt " +
                "FROM paiement p " +
                "JOIN contrat c ON p.idContrat = c.idContrat " +
                "JOIN client cl ON c.idClt = cl.idClt " +
                "WHERE p.idContrat = ?";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, idContrat);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Paiement paiement = new Paiement();
                paiement.setIdPaiement(resultSet.getInt("idPaiement"));
                paiement.setDatePaiement(resultSet.getTimestamp("datePaiement").toLocalDateTime());
                paiement.setMontantPaiement(resultSet.getInt("montantPaiement"));

                // Associer le nom du client
                Client client = new Client();
                client.setNomClt(resultSet.getString("nomClt"));
                paiement.setClient(client);

                paiements.add(paiement);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return paiements;
    }

    public static double getPaiementsAujourdhui() {
        double total = 0.0;

        String query = "SELECT SUM(montantPaiement) AS totalPaiement " +
                "FROM paiement " +
                "WHERE DATE(datePaiement) = CURDATE()";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            if (resultSet.next()) {
                total = resultSet.getDouble("totalPaiement");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return total;
    }



}
