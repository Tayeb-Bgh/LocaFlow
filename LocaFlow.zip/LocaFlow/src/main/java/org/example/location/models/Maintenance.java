package org.example.location.models;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Maintenance {

    private int idMaintenance;
    private LocalDate debMaintenance;
    private LocalDate finMaintenance;
    private int prixMaintenance;
    private Vehicule vehicule=new Vehicule();

    public Maintenance(int idMaintenance, LocalDate debMaintenance, LocalDate finMaintenance, int prixMaintenance) {
        this.idMaintenance=idMaintenance;
        this.debMaintenance=debMaintenance;
        this.finMaintenance=finMaintenance;
        this.prixMaintenance=prixMaintenance;
    }

    public Maintenance() {

    }

    public int getIdMaintenance() {
        return idMaintenance;
    }

    public void setIdMaintenance(int idMaintenance) {
        this.idMaintenance = idMaintenance;
    }

    public LocalDate getDebMaintenance() {
        return debMaintenance;
    }

    public void setDebMaintenance(LocalDate debMaintenance) {
        this.debMaintenance = debMaintenance;
    }

    public LocalDate getFinMaintenance() {
        return finMaintenance;
    }

    public void setFinMaintenance(LocalDate finMaintenance) {
        this.finMaintenance = finMaintenance;
    }

    public int getPrixMaintenance() {
        return prixMaintenance;
    }

    public void setPrixMaintenance(int prixMaintenance) {
        this.prixMaintenance = prixMaintenance;
    }

    public Vehicule getVehicule() {
        return vehicule;
    }

    public void setVehicule(Vehicule vehicule) {
        this.vehicule = vehicule;
    }

    public void setIdVeh(int currentVehId) {
        this.vehicule.setIdVeh(currentVehId);
    }

    public int getIdVeh() {
        return this.vehicule.getIdVeh();
    }
}
