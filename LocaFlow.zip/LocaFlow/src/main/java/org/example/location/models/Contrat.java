package org.example.location.models;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanExpression;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Contrat {
    private int idContrat;
    private LocalDateTime debContrat;
    private LocalDateTime finContrat;
    private double prixContrat;
    private double cautionContrat;
    private Boolean statutContrat;
    private LocalTime nbRetard;
    private Client client=new Client();
    private Vehicule vehicule=new Vehicule();
    private Employe employe=new Employe();
    private List<Prolongation> prolongations=new ArrayList<>();
    private List<Paiement> paiements=new ArrayList<>();

    public Contrat(int idContrat, LocalDateTime debContrat, LocalDateTime finContrat, double prixContrat) {
        this.idContrat = idContrat;
        this.debContrat = debContrat;
        this.finContrat = finContrat;
        this.prixContrat = prixContrat;
    }

    public Contrat() {

    }


    public int getIdContrat() {
        return idContrat;
    }

    public void setIdContrat(int idContrat) {
        this.idContrat = idContrat;
    }

    public LocalDateTime getDebContrat() {
        return debContrat;
    }

    public void setDebContrat(LocalDateTime debContrat) {
        this.debContrat = debContrat;
    }

    public LocalDateTime getFinContrat() {
        return finContrat;
    }

    public void setFinContrat(LocalDateTime finContrat) {
        this.finContrat = finContrat;
    }

    public double getPrixContrat() {
        return prixContrat;
    }

    public void setPrixContrat(double prixContrat) {
        this.prixContrat = prixContrat;
    }

    public double getCautionContrat() {
        return cautionContrat;
    }

    public void setCautionContrat(double cautionContrat) {
        this.cautionContrat = cautionContrat;
    }

    public Boolean getStatutContrat() {
        return statutContrat;
    }

    public void setStatutContrat(Boolean statutContrat) {
        this.statutContrat = statutContrat;
    }

    public LocalTime getNbRetard() {
        return nbRetard;
    }

    public void setNbRetard(LocalTime nbRetard) {
        this.nbRetard = nbRetard;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Vehicule getVehicule() {
        return vehicule;
    }

    public void setVehicule(Vehicule vehicule) {
        this.vehicule = vehicule;
    }

    public Employe getEmploye() {
        return employe;
    }

    public void setEmploye(Employe employe) {
        this.employe = employe;
    }

    public List<Prolongation> getProlongations() {
        return prolongations;
    }

    public void setProlongations(List<Prolongation> prolongations) {
        this.prolongations = prolongations;
    }

    public List<Paiement> getPaiements() {
        return paiements;
    }

    public void setPaiements(List<Paiement> paiements) {
        this.paiements = paiements;
    }

    public int getIdClient() {
        return client.getIdClt();
    }

    public int getIdVehicule() {
        return vehicule.getIdVeh();
    }

    public void setIdClient(int clientId) {
        this.client.setIdClt(clientId);
    }

    public void setIdVehicule(int vehicleId) {
        this.vehicule.setIdVeh(vehicleId);
    }


    public void setIdEmploye(int idEmp) {
        this.employe.setIdEmp(idEmp);
    }

    public void setNomClient(String clientName) {
        this.client.setNomClt(clientName);
    }

    public void setNomVehicule(String vehicleName) {
        this.vehicule.setModeleVeh(vehicleName);
    }

    // Méthode pour idContrat
    public IntegerProperty idContratProperty() {
        return new SimpleIntegerProperty(this, "idContrat", idContrat);
    }

    // Méthode pour prixContrat
    public DoubleProperty prixContratProperty() {
        return new SimpleDoubleProperty(this, "prixContrat", prixContrat);
    }


    public Contrat getContrat() {
        return this;
    }


}
