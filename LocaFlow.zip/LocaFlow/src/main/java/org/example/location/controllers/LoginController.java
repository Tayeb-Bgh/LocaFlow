package org.example.location.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.HelloApplication;
import org.example.location.dbUtils.DBUtils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private Stage stage;



    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    public void handleLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Champs vides", "Veuillez remplir tous les champs.");
            return;
        }

        try (Connection connection = DBUtils.getConnection()) {
            String query = "SELECT * FROM employe WHERE usernameEmp = ? AND mdpEmp = ? AND supprimerEmp = 0";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                statement.setString(2, password);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        // Connexion réussie, l'utilisateur est trouvé
                        HelloApplication.idEmploye = resultSet.getInt("idEmp");
                        HelloApplication.permission = resultSet.getBoolean("permissionEmp") ? 1 : 0;
                        setStage((Stage) ((Button) event.getSource()).getScene().getWindow());
                        stage.close();

                        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("view/Client/client-view.fxml"));
                        Scene scene = new Scene(fxmlLoader.load(), 1920, 1080);
                        stage.setTitle("Gestion de Location");
                        stage.setScene(scene);
                        stage.setMaximized(true);
                        stage.show();
                    } else {

                        showAlert("Erreur de connexion", "Nom d'utilisateur ou mot de passe incorrect.");
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur de connexion", "Un problème est survenu lors de la connexion à la base de données.");
        }
    }

    @FXML
    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
