package org.example.location.models;

import java.time.LocalDateTime;

public class Prolongation {
    private int idProlonge;
    private LocalDateTime finProlonge;
    private int prixProlonge;
    private Contrat contrat = new Contrat();

    public int getIdProlonge() {
        return idProlonge;
    }

    public void setIdProlonge(int idProlonge) {
        this.idProlonge = idProlonge;
    }

    public LocalDateTime getFinProlonge() {
        return finProlonge;
    }

    public void setFinProlonge(LocalDateTime finProlonge) {
        this.finProlonge = finProlonge;
    }

    public int getPrixProlonge() {
        return prixProlonge;
    }

    public void setPrixProlonge(int prixProlonge) {
        this.prixProlonge = prixProlonge;
    }

    public Contrat getContrat() {
        return contrat;
    }

    public void setContrat(Contrat contrat) {
        this.contrat = contrat;
    }

    public int getIdContrat() {
        return contrat.getIdContrat();
    }

    public void setIdContrat(int contratId) {
        contrat.setIdContrat(contratId);
    }
}
