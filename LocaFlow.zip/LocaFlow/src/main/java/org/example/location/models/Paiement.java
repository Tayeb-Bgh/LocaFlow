package org.example.location.models;

import java.time.LocalDateTime;

public class Paiement {
    private int idPaiement;
    private LocalDateTime datePaiement;
    private int montantPaiement;
    private Client client=new Client();
    private Contrat contrat=new Contrat();



    public int getIdPaiement() { return idPaiement; }
    public void setIdPaiement(int idPaiement) { this.idPaiement = idPaiement; }
    public LocalDateTime getDatePaiement() { return datePaiement; }
    public void setDatePaiement(LocalDateTime datePaiement) { this.datePaiement = datePaiement; }

    public int getMontantPaiement() {
        return montantPaiement;
    }

    public void setMontantPaiement(int montantPaiement) {
        this.montantPaiement = montantPaiement;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Contrat getContrat() {
        return contrat;
    }

    public void setContrat(Contrat contrat) {
        this.contrat = contrat;
    }
}