package org.example.location.controllers.Employe;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.dbUtils.ClientDAO;
import org.example.location.dbUtils.EmployeDao;
import org.example.location.models.Client;
import org.example.location.models.Employe;
import org.example.location.models.Suivie;
import org.example.location.models.Vehicule;

import java.time.LocalDate;
import java.time.Period;

public class EmployeAddController {

    public TextField nomField;
    public TextField prenomField;
    public TextField telField;
    public TextField adressField;
    public TextField ccpField;
    public TextField sexeField;
    public DatePicker dateNaissField;
    public TextField permissionField;
    public TextField usernameField;
    public TextField passwordField;
    private Stage stage;
    private boolean saveClicked = false;
    private Employe currentEmploye;

    public Employe getNewEmploye() {
        Employe newEmploye = new Employe();
        newEmploye.setNomEmp(nomField.getText());
        newEmploye.setPrenomEmp(prenomField.getText());
        newEmploye.setTelEmp(Integer.parseInt(telField.getText()));
        newEmploye.setAdressEmp(adressField.getText());
        newEmploye.setCcpEmp(Integer.parseInt(ccpField.getText()));
        newEmploye.setSexeEmp(sexeField.getText().charAt(0));
        newEmploye.setDateNaissEmp(dateNaissField.getValue());
        newEmploye.setPermissionEmp(Boolean.parseBoolean(permissionField.getText()));
        newEmploye.setUsernameEmp(usernameField.getText());
        newEmploye.setMdpEmp(passwordField.getText());


        return newEmploye;
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    @FXML
    public void handleSave(ActionEvent event) {
        Employe employe = getNewEmploye();

        if (!isInputValid()) {
            return;
        }

        if (currentEmploye != null) {
            // Mettre à jour l'employé existant
            employe.setIdEmp(currentEmploye.getIdEmp());
            EmployeDao.updateEmploye(employe);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("L'employé a été mis à jour avec succès.");
            alert.showAndWait();
        } else {
            // Ajouter un nouvel employé
            EmployeDao.addEmploye(employe);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("L'employé a été ajouté avec succès.");
            alert.showAndWait();
        }

        saveClicked = true; // Indiquer que les modifications sont enregistrées
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

        stage.close(); // Fermer le modal
    }
    private boolean isInputValid() {
        StringBuilder errorMessage = new StringBuilder();

        // Nom et prénom validation
        if (nomField.getText().isEmpty() || !nomField.getText().matches("[a-zA-Z]+")) {
            errorMessage.append("Le nom est obligatoire et doit contenir uniquement des lettres.\n");
        }
        if (prenomField.getText().isEmpty() || !prenomField.getText().matches("[a-zA-Z]+")) {
            errorMessage.append("Le prénom est obligatoire et doit contenir uniquement des lettres.\n");
        }

        // Téléphone validation
        if (!telField.getText().matches("^0[567][0-9]{8}$")) {
            errorMessage.append("Le numéro de téléphone doit avoir 10 chiffres et commencer par 06, 07 ou 05.\n");
        }

        // Adresse
        if (adressField.getText().isEmpty()) {
            errorMessage.append("L'adresse est obligatoire.\n");
        }

        // CCP validation
        if (!ccpField.getText().matches("\\d{6,}")) {
            errorMessage.append("Le numéro CCP doit contenir au moins 6 chiffres.\n");
        }

        // Sexe validation
        if (!sexeField.getText().equalsIgnoreCase("H") && !sexeField.getText().equalsIgnoreCase("F")) {
            errorMessage.append("Le sexe doit être H (Homme) ou F (Femme).\n");
        }

        // Date de naissance validation
        LocalDate birthDate = dateNaissField.getValue();
        if (birthDate == null || Period.between(birthDate, LocalDate.now()).getYears() < 18) {
            errorMessage.append("L'employé doit avoir au moins 18 ans.\n");
        }

        // Permission validation
        if (!permissionField.getText().equalsIgnoreCase("true") && !permissionField.getText().equalsIgnoreCase("false")) {
            errorMessage.append("La permission doit être 'true' ou 'false'.\n");
        }

        // Nom d'utilisateur validation
        if (usernameField.getText().isEmpty()) {
            errorMessage.append("Le nom d'utilisateur est obligatoire.\n");
        }

        // Mot de passe validation
        if (passwordField.getText().isEmpty() || passwordField.getText().length() < 6) {
            errorMessage.append("Le mot de passe doit contenir au moins 6 caractères.\n");
        }

        if (errorMessage.length() > 0) {
            showError("Champs invalides", errorMessage.toString());
            return false;
        }



        return true;
    }
    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    public void setEditMode(Employe employe) {
        nomField.setText(employe.getNomEmp());
        prenomField.setText(employe.getPrenomEmp());
        telField.setText(String.valueOf(employe.getTelEmp()));
        adressField.setText(employe.getAdressEmp());
        ccpField.setText(String.valueOf(employe.getCcpEmp()));
        sexeField.setText(String.valueOf(employe.getSexeEmp()));
        dateNaissField.setValue(employe.getDateNaissEmp());
        permissionField.setText(String.valueOf(employe.getPermissionEmp()));
        usernameField.setText(employe.getUsernameEmp());
        passwordField.setText(employe.getMdpEmp());
        this.currentEmploye = employe; // Stocker l'employé en cours d'édition
    }

}
