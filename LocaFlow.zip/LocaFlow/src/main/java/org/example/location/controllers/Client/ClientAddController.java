package org.example.location.controllers.Client;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.location.dbUtils.ClientDAO;
import org.example.location.models.Client;
import java.time.LocalDate;
import java.time.Period;

public class ClientAddController {
    @FXML private TextField nomField;
    @FXML private TextField prenomField;
    @FXML private DatePicker dateNaissancePicker;
    @FXML private TextField numPermisField;
    @FXML private DatePicker dateDelivrPermisPicker;
    @FXML private DatePicker dateExpPermisPicker;
    @FXML private TextField adresseField;
    @FXML private TextField telephoneField;
    @FXML private Button closeButton;

    private Client client;


    private Stage stage;
    private Client newClient;
    private boolean saveClicked = false;

    @FXML
    private void initialize() {

        setupValidation();
    }

    private void setupValidation() {

        numPermisField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                numPermisField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        // Validation du numéro de téléphone (nombres uniquement)
        telephoneField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                telephoneField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        // Empêcher la sélection de dates futures pour la date de naissance
        dateNaissancePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isAfter(LocalDate.now()));
            }
        });
    }

    @FXML
    private void handleSave() {
        if (client == null) {

            client = new Client();
        }
        if (!isInputValid()) return;
        // Mettre à jour les informations du client
        client.setNomClt(nomField.getText());
        client.setPrenomClt(prenomField.getText());
        client.setDateNaiss(dateNaissancePicker.getValue());
        client.setNumPermis(Integer.parseInt(numPermisField.getText()));
        client.setDateDelivrPermis(dateDelivrPermisPicker.getValue());
        client.setDateExprPermis(dateExpPermisPicker.getValue());
        client.setAdressClt(adresseField.getText());
        client.setTelClt(Integer.parseInt(telephoneField.getText()));

        // Enregistrer ou mettre à jour en fonction de l'état du client
        if (client.getIdClt() == 0) {
            // Ajouter un nouveau client
            ClientDAO.insertClient(client);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Le client a été ajouté avec succès.");
            alert.showAndWait();
        } else {
            // Mettre à jour un client existant
            ClientDAO.updateClient(client);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Le client a été mis à jour avec succès.");
            alert.showAndWait();
        }

        saveClicked = true; // Indiquer que les modifications sont enregistrées
        stage.close(); // Fermer le modal
    }


    public void setClientToEdit(Client client) {
        this.client = client; // Associer le client au formulaire
        if (client != null) {
            nomField.setText(client.getNomClt());
            prenomField.setText(client.getPrenomClt());
            dateNaissancePicker.setValue(client.getDateNaiss());

            // Vérification et affectation des dates
            if (client.getDateDelivrPermis() != null) {
                dateDelivrPermisPicker.setValue(client.getDateDelivrPermis());
            }
            if (client.getDateExprPermis() != null) {
                dateExpPermisPicker.setValue(client.getDateExprPermis());
            }

            numPermisField.setText(String.valueOf(client.getNumPermis()));
            adresseField.setText(client.getAdressClt());
            telephoneField.setText(String.valueOf(client.getTelClt()));
        }
    }

    private boolean isInputValid() {
        StringBuilder errorMessage = new StringBuilder();

        // Champs obligatoires
        if (nomField.getText().isEmpty()) errorMessage.append("Le nom est requis.\n");
        if (prenomField.getText().isEmpty()) errorMessage.append("Le prénom est requis.\n");
        if (adresseField.getText().isEmpty()) errorMessage.append("L'adresse est requise.\n");
        if (telephoneField.getText().isEmpty()) errorMessage.append("Le numéro de téléphone est requis.\n");
        if (numPermisField.getText().isEmpty()) errorMessage.append("Le numéro de permis est requis.\n");
        if (dateNaissancePicker.getValue() == null) errorMessage.append("La date de naissance est requise.\n");
        if (dateDelivrPermisPicker.getValue() == null) errorMessage.append("La date de délivrance du permis est requise.\n");
        if (dateExpPermisPicker.getValue() == null) errorMessage.append("La date d'expiration du permis est requise.\n");


        // Validation du numéro de téléphone
        String phone = telephoneField.getText();
        if (!phone.matches("^0[567][0-9]{8}$")) {
            errorMessage.append("Le numéro de téléphone doit avoir 10 chiffres et commencer par 06, 07 ou 05.\n");
        }

        // Vérification de l'âge (18 ans minimum)
        LocalDate dateNaissance = dateNaissancePicker.getValue();
        if (dateNaissance != null && Period.between(dateNaissance, LocalDate.now()).getYears() < 18) {
            errorMessage.append("Le client doit avoir au moins 18 ans.\n");
        }

        // Vérification des dates du permis
        LocalDate dateDelivrPermis = dateDelivrPermisPicker.getValue();
        LocalDate dateExpPermis = dateExpPermisPicker.getValue();
        if (dateDelivrPermis != null && dateExpPermis != null && dateExpPermis.isBefore(dateDelivrPermis)) {
            errorMessage.append("La date d'expiration du permis doit être postérieure à la date de délivrance.\n");
        }

        if (errorMessage.length() > 0) {
            showError("Champs invalides", errorMessage.toString());
            return false;
        }

        return true;
    }



    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    private void handleCancel() {
        stage.close();
    }

    @FXML
    private void handleClose() {
        stage.close();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Client getNewClient() {
        return newClient;
    }
}