package org.example.location.models;

import java.time.LocalDate;

public class Suivie {
    private int idOption;
    private LocalDate assuranceExp;
    private LocalDate controleTechExp;
    private int vidangeExp;
    private Vehicule vehicule;

    public Suivie(LocalDate assuranceExp, LocalDate controleTechExp, int vidangeExp) {
        this.assuranceExp = assuranceExp;
        this.controleTechExp = controleTechExp;
        this.vidangeExp = vidangeExp;
    }

    public Suivie() {

    }

    public int getIdOption() {
        return idOption;
    }

    public void setIdOption(int idOption) {
        this.idOption = idOption;
    }

    public LocalDate getAssuranceExp() {
        return assuranceExp;
    }

    public void setAssuranceExp(LocalDate assuranceExp) {
        this.assuranceExp = assuranceExp;
    }

    public LocalDate getControleTechExp() {
        return controleTechExp;
    }

    public void setControleTechExp(LocalDate controleTechExp) {
        this.controleTechExp = controleTechExp;
    }

    public int getVidangeExp() {
        return vidangeExp;
    }

    public void setVidangeExp(int vidangeExp) {
        this.vidangeExp = vidangeExp;
    }

    public Vehicule getVehicule() {
        return vehicule;
    }

    public void setVehicule(Vehicule vehicule) {
        this.vehicule = vehicule;
    }
}
