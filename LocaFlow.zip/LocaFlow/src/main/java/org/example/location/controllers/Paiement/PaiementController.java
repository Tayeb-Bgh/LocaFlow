package org.example.location.controllers.Paiement;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.location.HelloApplication;
import org.example.location.controllers.Switch;
import org.example.location.dbUtils.PaiementDao;
import org.example.location.models.Contrat;
import org.example.location.models.Paiement;

import java.io.IOException;

public class PaiementController {


    @FXML
    private TableView<Contrat> paiementTable;

    @FXML
    private TableColumn<Contrat, Integer> idContratColumn;

    @FXML
    private TableColumn<Contrat, String> nomClientColumn;

    @FXML
    private TableColumn<Contrat, String> nomVoitureColumn;

    @FXML
    private TableColumn<Contrat, String> dateDebutColumn;

    @FXML
    private TableColumn<Contrat, String> dateFinColumn;

    @FXML
    private TableColumn<Contrat, Double> montantTotalColumn;

    @FXML
    private TableColumn<Contrat, Double> montantPayeColumn;

    @FXML
    private TableColumn<Contrat, Double> montantRestantColumn;

    @FXML
    private TableColumn<Contrat, String> etatContratColumn;
    @FXML
    private TableColumn<Contrat, Void> actionColumn;

    private ObservableList<Contrat> contratsNonPayesList = FXCollections.observableArrayList();

    @FXML
    private TableView<Paiement> historiquePaiementsTable;

    @FXML
    private TableColumn<Paiement, Integer> idPaiementColumn;

    @FXML
    private TableColumn<Paiement, Integer> idContratHistoriqueColumn;

    @FXML
    private TableColumn<Paiement, String> nomClientHistoriqueColumn;

    @FXML
    private TableColumn<Paiement, String> datePaiementColumn;

    @FXML
    private TableColumn<Paiement, Integer> montantPayeHistoriqueColumn;

    private ObservableList<Paiement> historiquePaiementsList = FXCollections.observableArrayList();

    @FXML
    private Label totalNonPayeLabel;

    @FXML
    private Label contratsEnAttenteLabel;

    @FXML
    private Label paiementsAujourdhuiLabel;



    /**
     * Met à jour les valeurs des 3 boxes en haut.
     */
    private void loadStaticBoxData() {
        // 1️⃣ Total des montants non payés
        double totalMontantsNonPayes = PaiementDao.fetchNonPayedContracts().stream()
                .mapToDouble(paiement -> paiement.getContrat().getPrixContrat() - paiement.getContrat().getPaiements().stream().mapToDouble(Paiement::getMontantPaiement).sum())
                .filter(montantRestant -> montantRestant > 0)
                .sum();
        totalNonPayeLabel.setText(String.format("%.2f DA", totalMontantsNonPayes));

        // 2️⃣ Nombre de contrats en attente de paiement
        long contratsEnAttente = paiementTable.getItems().stream()
                .filter(paiement -> {
                    double montantPaye = paiement.getContrat().getPaiements()
                            .stream()
                            .mapToDouble(Paiement::getMontantPaiement)
                            .sum();
                    return paiement.getContrat().getPrixContrat() > montantPaye;
                })
                .map(paiement -> paiement.getContrat().getIdContrat())
                .distinct()
                .count();

        contratsEnAttenteLabel.setText(String.valueOf(contratsEnAttente));

        // 3️⃣ Paiements effectués aujourd'hui
        double paiementsAujourdhui = PaiementDao.getPaiementsAujourdhui();
        paiementsAujourdhuiLabel.setText(String.format("%.2f DA", paiementsAujourdhui));

    }



    @FXML
    public void initialize() {
        setupTableColumns();
        loadNonPayedContracts();
        setupActionColumn();
        loadHistoriquePaiements();
        loadStaticBoxData();
    }

    private void loadHistoriquePaiements() {
        historiquePaiementsList.clear();
        historiquePaiementsList.addAll(PaiementDao.fetchAllPaiements());

        idPaiementColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleObjectProperty<>(cellData.getValue().getIdPaiement()));

        idContratHistoriqueColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleObjectProperty<>(cellData.getValue().getContrat().getIdContrat()));

        nomClientHistoriqueColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getContrat().getClient().getNomClt()));

        datePaiementColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDatePaiement().toString()));

        montantPayeHistoriqueColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleObjectProperty<>(cellData.getValue().getMontantPaiement()));

        historiquePaiementsTable.setItems(historiquePaiementsList);
    }

    private void setupTableColumns() {
        idContratColumn.setCellValueFactory(cellData -> cellData.getValue().idContratProperty().asObject());
        nomClientColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getClient().getNomClt()));
        nomVoitureColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getVehicule().getModeleVeh()));
        dateDebutColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDebContrat().toString()));
        dateFinColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getFinContrat().toString()));
        montantTotalColumn.setCellValueFactory(cellData -> cellData.getValue().prixContratProperty().asObject());

        // Montant payé = Somme des paiements liés au contrat
        montantPayeColumn.setCellValueFactory(cellData -> {
            double totalPaiements = cellData.getValue().getPaiements().stream()
                    .mapToDouble(paiement -> paiement.getMontantPaiement())
                    .sum();
            return new javafx.beans.property.SimpleDoubleProperty(totalPaiements).asObject();
        });

        // Montant restant = Prix total - montant payé
        montantRestantColumn.setCellValueFactory(cellData -> {
            double totalPaiements = cellData.getValue().getPaiements().stream()
                    .mapToDouble(paiement -> paiement.getMontantPaiement())
                    .sum();
            double montantRestant = cellData.getValue().getPrixContrat() - totalPaiements;
            return new javafx.beans.property.SimpleDoubleProperty(montantRestant).asObject();
        });

        etatContratColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStatutContrat() ? "Terminé" : "En cours"));
    }

    private void setupActionColumn() {
        actionColumn.setCellFactory(param -> new TableCell<Contrat, Void>() {
            private final Button payerButton = new Button("Payer");
            private final Button detailsButton = new Button("Détails");
            private final HBox buttonsBox = new HBox(10, payerButton, detailsButton);

            {
                // Styles des boutons
                payerButton.getStyleClass().add("table-button");
                detailsButton.getStyleClass().add("table-button");

                // Action pour le bouton "Payer"
                payerButton.setOnAction(event -> {
                    Contrat contrat = getTableView().getItems().get(getIndex());
                    handlePayerAction(contrat);
                });

                // Action pour le bouton "Détails"
                detailsButton.setOnAction(event -> {
                    Contrat contrat = getTableView().getItems().get(getIndex());
                    handleDetailsAction(contrat);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(buttonsBox);
                }
            }
        });
    }


    private void handlePayerAction(Contrat contrat) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Paiement/paiement-payer-view.fxml"));
            Parent modalRoot = loader.load();

            PaiementPayerController controller = loader.getController();
            controller.setContratDetails(contrat);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initStyle(StageStyle.UNDECORATED);
            controller.setStage(stage);

            Scene modalScene = new Scene(modalRoot);
            stage.setScene(modalScene);
            stage.setTitle("Ajouter un Paiement");

            // Appliquer l'overlay semi-transparent et le flou
            Scene mainScene = paiementTable.getScene(); // Assurez-vous de pointer vers la scène principale
            Parent mainRoot = mainScene.getRoot();

            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);

            GaussianBlur blur = new GaussianBlur(10);
            ((Pane) mainRoot).getChildren().add(overlay);
            mainRoot.setEffect(blur);

            // Supprimer l'overlay et le flou après la fermeture du modal
            stage.setOnHidden(event -> {
                ((Pane) mainRoot).getChildren().remove(overlay);
                mainRoot.setEffect(null);
                loadNonPayedContracts();
            });

            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private void handleDetailsAction(Contrat contrat) {
        try {
            // Charger le fichier FXML pour la vue des détails
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Paiement/paiement-details-view.fxml"));
            Parent root = loader.load();

            // Récupérer le contrôleur et lui transmettre les données
            PaiementDetailsController controller = loader.getController();
            controller.setContratDetails(contrat);

            // Créer une nouvelle fenêtre modale
            Stage modalStage = new Stage();
            modalStage.initModality(Modality.APPLICATION_MODAL);
            modalStage.initStyle(StageStyle.UNDECORATED);
            modalStage.setTitle("Détails du Contrat");

            // Effet de blur et overlay sur la fenêtre principale
            Scene mainScene = paiementTable.getScene();
            HBox rootMain = (HBox) mainScene.getRoot(); // Assure-toi que ta racine est bien un HBox
            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(Color.color(0, 0, 0, 0.5)); // Fond semi-transparent
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);

            GaussianBlur blur = new GaussianBlur(10);
            rootMain.getChildren().add(overlay);
            rootMain.setEffect(blur);

            // Définir la scène du modal
            Scene modalScene = new Scene(root, 600, 690);
            modalStage.setScene(modalScene);

            // Restaurer l'effet lorsqu'on ferme la fenêtre modale
            modalStage.setOnHidden(event -> {
                rootMain.getChildren().remove(overlay);
                rootMain.setEffect(null);
            });

            // Afficher la fenêtre modale
            modalStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private void loadNonPayedContracts() {
        contratsNonPayesList.clear();
        contratsNonPayesList.addAll(PaiementDao.fetchNonPayedContracts());
        paiementTable.setItems(contratsNonPayesList);
    }

    @FXML
    private void handleDashboard(MouseEvent event) {
        Switch.changeScene(event, "view/Dashboard/dashboard-view.fxml");
    }


    @FXML
    private void handleClient(MouseEvent event) {
        Switch.changeScene(event, "view/Client/client-view.fxml");
    }

    @FXML
    private void handleVehicules(MouseEvent event){
        Switch.changeScene(event,"view/Voiture/voiture-view.fxml");
    }

    @FXML
    private void handleLocations(MouseEvent event){
        Switch.changeScene(event,"view/Location/location-view.fxml");
    }

    @FXML
    private void handlePaiements(MouseEvent event){
        Switch.changeScene(event,"view/Paiement/paiement-view.fxml");
    }

    public void handleEmploye(MouseEvent event) {
        if (HelloApplication.permission == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Accès refusé");
            alert.setHeaderText("Accès refusé");
            alert.setContentText("Vous devez avoir un compte admin pour acceder au menu Employé");
            alert.showAndWait();
            return;
        }
        Switch.changeScene(event, "view/Employe/employe-view.fxml");
    }

}
