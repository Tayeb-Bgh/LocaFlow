package org.example.location.controllers.Employe;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.location.dbUtils.EmployeDao;
import org.example.location.models.Contrat;
import org.example.location.models.Employe;

import java.util.List;

public class EmployeDetailsController {

    @FXML
    private Label nomLabel;

    @FXML
    private Label prenomLabel;

    @FXML
    private Label telLabel;

    @FXML
    private Label adressLabel;

    @FXML
    private Label sexeLabel;

    @FXML
    private Label dateNaissLabel;

    @FXML
    private Label ccpLabel;

    @FXML
    private Label permissionLabel;

    @FXML
    private Label usernameLabel;

    @FXML
    private Label passwordLabel;

    // TableView pour l'historique des contrats créés
    @FXML
    private TableView<Contrat> contratsTable;

    @FXML
    private TableColumn<Contrat, Integer> idContratColumn;

    @FXML
    private TableColumn<Contrat, String> nomClientColumn;

    @FXML
    private TableColumn<Contrat, String> dateDebutColumn;

    @FXML
    private TableColumn<Contrat, String> dateFinColumn;

    /**
     * Initialise les colonnes de la TableView
     */
    @FXML
    public void initialize() {
        idContratColumn.setCellValueFactory(new PropertyValueFactory<>("idContrat"));
        nomClientColumn.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(
                        param.getValue().getClient().getNomClt() + " " + param.getValue().getClient().getPrenomClt()
                ));
        dateDebutColumn.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(param.getValue().getDebContrat().toLocalDate().toString())
        );
        dateFinColumn.setCellValueFactory(param ->
                new javafx.beans.property.SimpleStringProperty(param.getValue().getFinContrat().toLocalDate().toString())
        );
    }

    /**
     * Sets the details of the employee and loads the contracts.
     *
     * @param employe The employee whose details are to be displayed.
     */
    public void setEmployeDetails(Employe employe) {
        nomLabel.setText(employe.getNomEmp());
        prenomLabel.setText(employe.getPrenomEmp());
        telLabel.setText(String.valueOf(employe.getTelEmp()));
        adressLabel.setText(employe.getAdressEmp());
        sexeLabel.setText(String.valueOf(employe.getSexeEmp()));
        dateNaissLabel.setText(employe.getDateNaissEmp().toString());
        ccpLabel.setText(String.valueOf(employe.getCcpEmp()));
        permissionLabel.setText(employe.getPermissionEmp() ? "Oui" : "Non");
        usernameLabel.setText(employe.getUsernameEmp());
        passwordLabel.setText(employe.getMdpEmp());

        // Charger l'historique des contrats créés
        loadContratsHistory(employe.getIdEmp());
    }

    private void loadContratsHistory(int employeId) {
        List<Contrat> contrats = EmployeDao.getContratsByEmployeId(employeId);
        contratsTable.getItems().clear();
        contratsTable.getItems().addAll(contrats);
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) nomLabel.getScene().getWindow();
        stage.close();
    }
}
