package org.example.location.dbUtils;

import org.example.location.models.Agence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AgenceDao {

    public static Agence getAgence() {
        String query = "SELECT * FROM agence LIMIT 1";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return new Agence(
                        rs.getInt("idAgence"),
                        rs.getString("nomAgence"),
                        rs.getString("telAgence"),
                        rs.getString("adressAgence"),
                        rs.getString("faxAgence"),
                        rs.getString("registreAgence"),
                        rs.getString("codeFiscalAgence"),
                        rs.getString("articleImpositionAgence"),
                        rs.getString("reglementAgence"),
                        rs.getString("remarqueAgence")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void updateAgence(Agence agence) {
        String query = """
            UPDATE agence SET nomAgence=?, telAgence=?, adressAgence=?, faxAgence=?, registreAgence=?, 
            codeFiscalAgence=?, articleImpositionAgence=?, reglementAgence=?, remarqueAgence=? WHERE idAgence=?
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, agence.getNomAgence());
            ps.setString(2, agence.getTelAgence());
            ps.setString(3, agence.getAdressAgence());
            ps.setString(4, agence.getFaxAgence());
            ps.setString(5, agence.getRegistreAgence());
            ps.setString(6, agence.getCodeFiscalAgence());
            ps.setString(7, agence.getArticleImpositionAgence());
            ps.setString(8, agence.getReglementAgence());
            ps.setString(9, agence.getRemarqueAgence());
            ps.setInt(10, agence.getIdAgence());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
