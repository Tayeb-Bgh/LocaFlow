package org.example.location.controllers.Client;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.location.dbUtils.ClientDAO;
import org.example.location.dbUtils.ClientDAO;
import org.example.location.models.Client;
import org.example.location.models.Contrat;

public class ClientDetailsController {

    @FXML
    private Label idLabel;
    @FXML
    public Label nomLabel;
    @FXML
    public Label prenomLabel;
    @FXML
    public Label dateNaissanceLabel;
    @FXML
    public Label numPermisLabel;
    @FXML
    public Label adresseLabel;
    @FXML
    public Label telephoneLabel;
    @FXML
    public Label dateExpPermisLabel;

    @FXML
    private TableView<Contrat> historiqueTable;

    @FXML
    private TableColumn<Contrat, Integer> idContratColumn;
    @FXML
    private TableColumn<Contrat, String> dateDebutColumn;
    @FXML
    private TableColumn<Contrat, String> dateFinColumn;
    @FXML
    private TableColumn<Contrat, Integer> prixColumn;

    private ObservableList<Contrat> contratsList = FXCollections.observableArrayList();

    public void initialize() {
        // Configuration des colonnes de la TableView
        idContratColumn.setCellValueFactory(new PropertyValueFactory<>("idContrat"));
        dateDebutColumn.setCellValueFactory(new PropertyValueFactory<>("debContrat"));
        dateFinColumn.setCellValueFactory(new PropertyValueFactory<>("finContrat"));
        prixColumn.setCellValueFactory(new PropertyValueFactory<>("prixContrat"));
    }

    public void setClientDetails(Client client) {
        // Remplissage des labels
        idLabel.setText(String.valueOf(client.getIdClt()));
        nomLabel.setText(client.getNomClt());
        prenomLabel.setText(client.getPrenomClt());
        dateNaissanceLabel.setText(client.getDateNaiss().toString());
        numPermisLabel.setText(String.valueOf(client.getNumPermis()));
        adresseLabel.setText(client.getAdressClt());
        telephoneLabel.setText(String.valueOf(client.getTelClt()));
        dateExpPermisLabel.setText(client.getDateExprPermis().toString());

        // Charger les contrats du client dans la TableView
        loadHistoriqueContrats(client.getIdClt());
    }

    private void loadHistoriqueContrats(int clientId) {
        contratsList.clear();
        contratsList.addAll(ClientDAO.getHistoriqueContratsParClient(clientId));
        historiqueTable.setItems(contratsList);
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) idLabel.getScene().getWindow();
        stage.close();
    }
}
