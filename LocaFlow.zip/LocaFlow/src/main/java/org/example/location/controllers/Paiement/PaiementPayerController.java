package org.example.location.controllers.Paiement;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.location.dbUtils.PaiementDao;
import org.example.location.models.Contrat;

import java.time.LocalDate;

public class PaiementPayerController {

    @FXML
    private Label nomClientLabel;

    @FXML
    private Label nomVehiculeLabel;

    @FXML
    private Label montantTotalLabel;

    @FXML
    private Label montantRestantLabel;

    @FXML
    private TextField montantPayeField;

    @FXML
    private DatePicker datePaiementPicker;

    private Stage stage;
    private Contrat contrat;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setContratDetails(Contrat contrat) {
        this.contrat = contrat;
        nomClientLabel.setText(contrat.getClient().getNomClt());
        nomVehiculeLabel.setText(contrat.getVehicule().getModeleVeh());
        montantTotalLabel.setText(String.valueOf(contrat.getPrixContrat()) + " DA");
        montantRestantLabel.setText(String.valueOf(contrat.getPrixContrat() - calculateMontantPaye()) + " DA");
    }

    private double calculateMontantPaye() {
        return PaiementDao.getTotalPaiementsForContrat(contrat.getIdContrat());
    }

    @FXML
    private void handleSave() {
        try {
            String montantPayeText = montantPayeField.getText();
            LocalDate datePaiement = datePaiementPicker.getValue();


            if (!isInputValid(montantPayeText, datePaiement)) {
                return;
            }

            double montantPaye = Double.parseDouble(montantPayeText);
            double montantRestant = contrat.getPrixContrat() - calculateMontantPaye();


            if (montantPaye <= 0) {
                showError("Le montant payé doit être supérieur à 0 !");
                return;
            }

            if (montantPaye > montantRestant) {
                showError("Le montant payé ne peut pas dépasser le montant restant de " + montantRestant + " DA !");
                return;
            }


            PaiementDao.insertPaiement(contrat.getIdContrat(), montantPaye, datePaiement);

            showInfo("Paiement enregistré avec succès !");
            stage.close();

        } catch (NumberFormatException e) {
            showError("Veuillez entrer un montant valide !");
        } catch (Exception e) {
            e.printStackTrace();
            showError("Une erreur est survenue lors de l'enregistrement du paiement.");
        }
    }

    @FXML
    private void handleCancel() {
        stage.close();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Succès");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isInputValid(String montantPayeText, LocalDate datePaiement) {
        StringBuilder errorMessage = new StringBuilder();

        // Vérification du montant payé
        if (montantPayeText == null || montantPayeText.trim().isEmpty()) {
            errorMessage.append("Le champ 'Montant payé' est requis.\n");
        } else {
            try {
                double montant = Double.parseDouble(montantPayeText);
                if (montant <= 0) {
                    errorMessage.append("Le montant payé doit être supérieur à 0.\n");
                }
            } catch (NumberFormatException e) {
                errorMessage.append("Le montant payé doit être un nombre valide.\n");
            }
        }


        if (datePaiement == null) {
            errorMessage.append("La date de paiement est requise.\n");
        } else {
            LocalDate today = LocalDate.now();
            LocalDate minDate = today.minusDays(2);

            if (datePaiement.isAfter(today)) {
                errorMessage.append("La date de paiement ne peut pas être dans le futur.\n");
            }

            if (datePaiement.isBefore(minDate)) {
                errorMessage.append("La date de paiement ne peut pas être antérieure à " + minDate + ".\n");
            }
        }


        if (errorMessage.length() > 0) {
            showError("Erreurs de saisie", errorMessage.toString());
            return false;
        }

        return true;
    }


    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
