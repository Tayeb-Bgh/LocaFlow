package org.example.location.controllers.Location;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.location.HelloApplication;
import org.example.location.controllers.Switch;
import org.example.location.dbUtils.LocationDao;
import org.example.location.models.Contrat;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Collectors;


public class LocationController {

    @FXML
    private TableView<Contrat> locationsTable;

    @FXML
    private TableColumn<Contrat, Integer> idColumn;

    @FXML
    private TableColumn<Contrat, String> clientColumn;

    @FXML
    private TableColumn<Contrat, String> vehiculeColumn;

    @FXML
    private TableColumn<Contrat, LocalDateTime> dateDebutColumn;

    @FXML
    private TableColumn<Contrat, LocalDateTime> dateFinColumn;

    @FXML
    private TableColumn<Contrat, Double> prixColumn;

    @FXML
    private TableColumn<Contrat, Double> cautionColumn;

    @FXML
    private TableColumn<Contrat, String> statutColumn;

    @FXML
    private TableColumn<Contrat, String> prolongationColumn;

    @FXML
    private TableColumn<Contrat, String> retardColumn;

    @FXML
    private TableColumn<Contrat, Void> actionColumn;

    @FXML
    private Label totalLocationsLabel;

    @FXML
    private Label locationsEnCoursLabel;

    @FXML
    private Label locationsTermineesLabel;

    @FXML
    private Label retardsLabel;

    @FXML
    private TextField searchField;

    @FXML
    private ComboBox<String> filterComboBox;

    private ObservableList<Contrat> locationsList = FXCollections.observableArrayList();
    private ObservableList<Contrat> filteredList = FXCollections.observableArrayList();


    @FXML
    public void initialize() {
        setupTableColumns();
        loadData();
        setupSearch();
        updateStats();
        setupFilterComboBox();
    }


    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idContrat"));
        clientColumn.setCellValueFactory(new PropertyValueFactory<>("nomClient"));
        clientColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getClient().getNomClt()));
        vehiculeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getVehicule().getModeleVeh()));
        dateDebutColumn.setCellValueFactory(new PropertyValueFactory<>("debContrat"));
        dateFinColumn.setCellValueFactory(new PropertyValueFactory<>("finContrat"));
        prixColumn.setCellValueFactory(new PropertyValueFactory<>("prixContrat"));
        cautionColumn.setCellValueFactory(new PropertyValueFactory<>("cautionContrat"));

        statutColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStatutContrat() == true ? "Terminé" : "En cours"));

        setupActionColumn();

        locationsTable.setItems(filteredList);

    }

    private void setupActionColumn() {
        actionColumn.setCellFactory(param -> new TableCell<>() {

            private final FontAwesomeIconView deleteIcon = new FontAwesomeIconView(FontAwesomeIcon.TRASH);
            private final FontAwesomeIconView viewIcon = new FontAwesomeIconView(FontAwesomeIcon.EYE);

            {

                deleteIcon.setStyleClass("action-icon");
                viewIcon.setStyleClass("action-icon");


                deleteIcon.setOnMouseClicked(event -> handleDeleteAction(event));
                viewIcon.setOnMouseClicked(event -> {
                    try {
                        handleViewDetails(event);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });


                deleteIcon.setSize("1.8em");
                viewIcon.setSize("1.8em");
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox container = new HBox(10, deleteIcon, viewIcon);
                    container.setAlignment(Pos.CENTER);
                    setGraphic(container);
                }
            }
        });
    }


    @FXML
    private void handleDeleteAction(MouseEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText(null);
        alert.setContentText("Etes-vous sur de vouloir supprimer ce contrat ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            Contrat contrat = locationsTable.getSelectionModel().getSelectedItem();
            LocationDao.deleteLocation(contrat.getIdContrat());
        }

        loadData();
    }

    private void loadData() {
        locationsList.clear();
        locationsList.addAll(LocationDao.fetchAllLocations());
        filteredList.setAll(locationsList);
    }








    private void updateStats() {
        totalLocationsLabel.setText(String.valueOf(locationsList.size()));
        locationsEnCoursLabel.setText(String.valueOf(
                locationsList.stream().filter(contrat -> !contrat.getStatutContrat()).count()
        ));
        locationsTermineesLabel.setText(String.valueOf(
                locationsList.stream().filter(Contrat::getStatutContrat).count()
        ));
    }



    @FXML
    private void handleAddLocation() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Location/location-add-view.fxml"));
            Scene modalScene = new Scene(loader.load(), 400, 500);

            LocationAddController controller = loader.getController();
            Stage modalStage = new Stage();
            modalStage.initModality(Modality.APPLICATION_MODAL);
            modalStage.initStyle(StageStyle.UNDECORATED);
            modalStage.setScene(modalScene);
            controller.setStage(modalStage);

            Scene mainScene = locationsTable.getScene();
            HBox root = (HBox) mainScene.getRoot();
            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);

            GaussianBlur blur = new GaussianBlur(10);
            root.getChildren().add(overlay);
            root.setEffect(blur);

            modalStage.setOnHidden(e -> {
                root.getChildren().remove(overlay);
                root.setEffect(null);
                loadData();
            });

            modalStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleDashboard(MouseEvent event) {
        Switch.changeScene(event, "view/Dashboard/dashboard-view.fxml");
    }


    public void handleClient(MouseEvent event) {
        Switch.changeScene(event,"view/Client/client-view.fxml");
    }

    @FXML
    private void handleVehicules(MouseEvent event){
        Switch.changeScene(event,"view/Voiture/voiture-view.fxml");
    }

    @FXML
    private void handleLocations() {}

    @FXML
    private void handlePaiements(MouseEvent event) {
        Switch.changeScene(event, "view/Paiement/paiement-view.fxml");
    }

    public void handleEmploye(MouseEvent event) {
        if (HelloApplication.permission == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Accès refusé");
            alert.setHeaderText("Accès refusé");
            alert.setContentText("Vous devez avoir un compte admin pour acceder au menu Employé");
            alert.showAndWait();
            return;
        }
        Switch.changeScene(event, "view/Employe/employe-view.fxml");
    }
    @FXML
    public void handleViewDetails(MouseEvent event) throws IOException {
        Contrat selectedContrat = locationsTable.getSelectionModel().getSelectedItem();
        if (selectedContrat == null) return;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/example/location/view/Location/location-details-view.fxml"));
        Scene modalScene = new Scene(fxmlLoader.load(), 800, 600);
        selectedContrat = LocationDao.getContratById(selectedContrat.getIdContrat());

        LocationDetailsController controller = fxmlLoader.getController();
        controller.setLocationDetails(selectedContrat);
        Stage modalStage = new Stage();
        modalStage.initModality(Modality.APPLICATION_MODAL);
        modalStage.initStyle(StageStyle.UNDECORATED);
        modalStage.setScene(modalScene);

        Scene mainScene = locationsTable.getScene();
        HBox root = (HBox) mainScene.getRoot();
        Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
        overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
        overlay.setManaged(false);
        overlay.setMouseTransparent(true);
        GaussianBlur blur = new GaussianBlur(10);

        root.getChildren().add(overlay);
        root.setEffect(blur);

        modalStage.setOnHidden(e -> {
            root.getChildren().remove(overlay);
            root.setEffect(null);
        });

        modalStage.showAndWait();
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filterLocations(newValue, filterComboBox.getValue());
        });
    }
    private void setupFilterComboBox() {
        filterComboBox.getItems().addAll("Tous", "Nom Client", "Véhicule", "Date Début", "Date Fin", "Statut");
        filterComboBox.setValue("Tous");

        filterComboBox.setOnAction(event -> {
            filterLocations(searchField.getText(), filterComboBox.getValue());
        });
    }

    private void filterLocations(String searchText, String filterCriteria) {
        if (searchText == null) searchText = "";
        String lowerCaseSearchText = searchText.toLowerCase();

        filteredList.setAll(
                locationsList.stream().filter(contrat -> {
                    boolean matchesFilter = false;

                    // Filtrage par critère sélectionné
                    switch (filterCriteria) {
                        case "Nom Client":
                            matchesFilter = contrat.getClient().getNomClt().toLowerCase().contains(lowerCaseSearchText);
                            break;
                        case "Véhicule":
                            matchesFilter = contrat.getVehicule().getModeleVeh().toLowerCase().contains(lowerCaseSearchText);
                            break;
                        case "Date Début":
                            matchesFilter = contrat.getDebContrat().toString().toLowerCase().contains(lowerCaseSearchText);
                            break;
                        case "Date Fin":
                            matchesFilter = contrat.getFinContrat().toString().toLowerCase().contains(lowerCaseSearchText);
                            break;
                        case "Statut":
                            matchesFilter = (contrat.getStatutContrat() ? "Terminé" : "En cours")
                                    .toLowerCase().contains(lowerCaseSearchText);
                            break;
                        default: // "Tous"
                            matchesFilter = contrat.getClient().getNomClt().toLowerCase().contains(lowerCaseSearchText)
                                    || contrat.getVehicule().getModeleVeh().toLowerCase().contains(lowerCaseSearchText)
                                    || contrat.getDebContrat().toString().toLowerCase().contains(lowerCaseSearchText)
                                    || contrat.getFinContrat().toString().toLowerCase().contains(lowerCaseSearchText)
                                    || (contrat.getStatutContrat() ? "Terminé" : "En cours")
                                    .toLowerCase().contains(lowerCaseSearchText);
                            break;
                    }
                    return matchesFilter;
                }).collect(Collectors.toList())
        );

        updateStats(); // Met à jour le total des résultats affichés
    }

    @FXML
    private void handleFilterTotalLocations() {
        filteredList.setAll(locationsList); // Réinitialise la liste à toutes les locations
        updateStats();
    }

    @FXML
    private void handleFilterLocationsEnCours() {
        filteredList.setAll(
                locationsList.stream()
                        .filter(contrat -> !contrat.getStatutContrat()) // Statut en cours
                        .collect(Collectors.toList())
        );
        updateStats();
    }

    @FXML
    private void handleFilterLocationsTerminees() {
        filteredList.setAll(
                locationsList.stream()
                        .filter(Contrat::getStatutContrat) // Statut terminé
                        .collect(Collectors.toList())
        );
        updateStats();
    }

}
