package org.example.location.controllers.Location;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.dbUtils.LocationDao;
import org.example.location.models.Prolongation;

import java.time.LocalDate;

public class ProlongationAddController {

    @FXML
    private DatePicker dateProlongationField;

    @FXML
    private TextField prixProlongationField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Stage stage;
    private int contratId;
    private boolean saveClicked = false;

    /**
     * Définit l'ID du contrat concerné par la prolongation.
     *
     * @param contratId L'identifiant du contrat
     */
    public void setContratId(int contratId) {
        this.contratId = contratId;
    }

    /**
     * Définit la fenêtre (stage) de la vue.
     *
     * @param stage La fenêtre actuelle
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    /**
     * Méthode appelée lors du clic sur le bouton "Enregistrer".
     *
     * @param event L'événement de clic
     */
    @FXML
    public void handleSave(ActionEvent event) {
        if (isInputValid()) {
            // Création d'une nouvelle prolongation
            Prolongation prolongation = new Prolongation();
            prolongation.setIdContrat(contratId);
            prolongation.setFinProlonge(dateProlongationField.getValue().atStartOfDay()); // Conversion de LocalDate en LocalDateTime
            prolongation.setPrixProlonge(Integer.parseInt(prixProlongationField.getText()));

            // Enregistrer la prolongation dans la base de données
            LocationDao.addProlongation(prolongation);

            // Marquer l'enregistrement comme effectué
            saveClicked = true;
            stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

            stage.close();
        }
    }

    /**
     * Méthode appelée lors du clic sur le bouton "Annuler".
     *
     * @param event L'événement de clic
     */
    @FXML
    public void handleCancel(ActionEvent event) {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

        stage.close();
    }

    /**
     * Valide les champs d'entrée avant l'enregistrement.
     *
     * @return true si les champs sont valides, sinon false
     */
    private boolean isInputValid() {
        StringBuilder errorMessage = new StringBuilder();

        // Vérification de la date de prolongation
        if (dateProlongationField.getValue() == null) {
            errorMessage.append("La date de prolongation est obligatoire.\n");
        }

        // Vérification du prix de la prolongation
        if (prixProlongationField.getText() == null || prixProlongationField.getText().isEmpty()) {
            errorMessage.append("Le prix de la prolongation est obligatoire.\n");
        } else {
            try {
                double prix = Double.parseDouble(prixProlongationField.getText());
                if (prix < 0) {
                    errorMessage.append("Le prix de la prolongation ne peut pas être négatif.\n");
                }
            } catch (NumberFormatException e) {
                errorMessage.append("Le prix de la prolongation doit être un nombre valide.\n");
            }
        }
        if (dateProlongationField.getValue().isAfter(LocationDao.getLastDate(contratId))==false) {
            errorMessage.append("La date de prolongation doit être postérieure à la date de fin du contrat.\n");
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Champs invalides");
            alert.setHeaderText("Corrigez les champs suivants :");
            alert.setContentText(errorMessage.toString());
            alert.showAndWait();
            return false;
        }
    }

    /**
     * Indique si l'utilisateur a cliqué sur le bouton "Enregistrer".
     *
     * @return true si l'utilisateur a cliqué sur "Enregistrer", sinon false
     */
    public boolean isSaveClicked() {
        return saveClicked;
    }
}
