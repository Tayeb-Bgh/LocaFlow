package org.example.location.controllers.Dashboard;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.input.MouseEvent;
import org.example.location.HelloApplication;
import org.example.location.controllers.Switch;
import org.example.location.dbUtils.DashboardDao;
import org.example.location.models.Contrat;
import org.example.location.models.Vehicule;

import java.util.List;
import java.util.Map;

public class DashboardController {

    @FXML
    private BarChart<String, Number> revenusGraph;

    @FXML
    private VBox notificationsPane;

    @FXML
    private VBox todayContractsPane;

    @FXML
    private VBox availableVehiclesPane;

    @FXML
    private Label totalClientsLabel;

    @FXML
    private Label clientsReservationLabel;

    @FXML
    private Label clientsNoContractLabel;

    @FXML
    public void initialize() {
        loadRevenusGraph();
        loadNotifications();
        loadTodayContracts();
        loadAvailableVehicles();
        loadTopBoxes();
    }

    /**
     * Charge le graphe des revenus mensuels.
     */
    private void loadRevenusGraph() {

            if (HelloApplication.permission == 0) {

                return;
            }


        revenusGraph.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Revenus");

        Map<String, Double> revenusMensuels = DashboardDao.getRevenusMensuels();
        for (Map.Entry<String, Double> entry : revenusMensuels.entrySet()) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        revenusGraph.getData().add(series);
    }


    private void loadNotifications() {
        notificationsPane.getChildren().clear();

        List<String> notifications = DashboardDao.getNotifications();
        for (String notification : notifications) {
            HBox row = new HBox(10);
            row.getStyleClass().add("dashboard-list-item");

            // Déterminer l'icône appropriée
            Label iconLabel = new Label();
            iconLabel.getStyleClass().add("dashboard-left-icon");

            if (notification.contains("Assurance expirée")) {
                iconLabel.setText("⚠ " );
            } else if (notification.contains("Contrôle technique")) {
                iconLabel.setText("⚠ ");
            } else if (notification.contains("Vidange")) {
                iconLabel.setText("🛠 ");
            } else {
                iconLabel.setText("🔔 "); // Icône générique par défaut
            }

            // Texte de la description
            Label descriptionLabel = new Label(notification);
            descriptionLabel.getStyleClass().add("dashboard-description-label");
            descriptionLabel.setWrapText(true);
            descriptionLabel.setMaxWidth(400);

            // Ajouter l'icône à gauche et le texte à droite
            row.getChildren().addAll(iconLabel,descriptionLabel);
            notificationsPane.getChildren().add(row);
        }
    }




    private void loadTodayContracts() {
        todayContractsPane.getChildren().clear();

        List<Contrat> contrats = DashboardDao.getContratsFinissantAujourdhui();
        for (Contrat contrat : contrats) {
            HBox row = new HBox(10);
            row.getStyleClass().add("dashboard-list-item");


            Label iconLabel = new Label("🗓");
            iconLabel.getStyleClass().add("dashboard-icon-label");

            Label descriptionLabel = new Label(
                    "Contrat ID: " + contrat.getIdContrat() +
                            " - Client: " + contrat.getClient().getNomClt() + " " + contrat.getClient().getPrenomClt() +
                            " - Voiture: " + contrat.getVehicule().getModeleVeh()
            );
            descriptionLabel.getStyleClass().add("dashboard-description-label");


            row.getChildren().addAll(iconLabel, descriptionLabel);


            todayContractsPane.getChildren().add(row);
        }
    }



    private void loadAvailableVehicles() {
        availableVehiclesPane.getChildren().clear();

        List<Vehicule> vehicules = DashboardDao.getVehiculesDisponibles();
        for (Vehicule vehicule : vehicules) {
            HBox row = new HBox(10);
            row.getStyleClass().add("dashboard-list-item");

            // Icône pour véhicule
            Label iconLabel = new Label("🚗");
            iconLabel.getStyleClass().add("dashboard-icon-label");

            // Texte pour les détails du véhicule
            Label descriptionLabel = new Label(
                    "Voiture: " +vehicule.getMarqueVeh() +" "+ vehicule.getModeleVeh() +
                            " - ID: " + vehicule.getIdVeh() +
                            " - Énergie: " + vehicule.getEnergieVeh()
            );
            descriptionLabel.getStyleClass().add("dashboard-description-label");
            descriptionLabel.setWrapText(true);
            descriptionLabel.setMaxWidth(400);

            // Ajouter les Labels à la ligne
            row.getChildren().addAll(iconLabel, descriptionLabel);

            // Ajouter la ligne au conteneur principal
            availableVehiclesPane.getChildren().add(row);
        }
    }



    private void loadTopBoxes() {
        totalClientsLabel.setText(String.valueOf(DashboardDao.getNombreContratsEnCours()));
        clientsReservationLabel.setText(String.valueOf(DashboardDao.getNombreContratsFinissantAujourdhui()));
        clientsNoContractLabel.setText(String.valueOf(DashboardDao.getNombreVehiculesDisponibles()));
    }


    @FXML
    private void handleVehicules(MouseEvent event) {
        Switch.changeScene(event, "view/Voiture/voiture-view.fxml");
    }

    @FXML
    private void handleLocations(MouseEvent event) {
        Switch.changeScene(event, "view/Location/location-view.fxml");
    }

    @FXML
    private void handlePaiements(MouseEvent event) {
        Switch.changeScene(event, "view/Paiement/paiement-view.fxml");
    }

    @FXML
    private void handleClient(MouseEvent event) {
        Switch.changeScene(event, "view/Client/client-view.fxml");
    }

    public void handleEmploye(MouseEvent event) {
        if (HelloApplication.permission == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Accès refusé");
            alert.setHeaderText("Accès refusé");
            alert.setContentText("Vous devez avoir un compte admin pour acceder au menu Employé");
            alert.showAndWait();
            return;
        }
        Switch.changeScene(event, "view/Employe/employe-view.fxml");
    }

    @FXML
    private void handleOpenAgenceDetails(MouseEvent event) {

    }

    public void handleDashboard(MouseEvent event) {
    }
}
