package org.example.location.dbUtils;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.location.models.Client;
import org.example.location.models.Contrat;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO {
    public static void insertClient(Client client){
        String query = "INSERT INTO client(nomClt,prenomClt,dateNaiss,numPermis,adressClt,telClt,dateExprPermis,dateDelivrPermis,supprimerClt)" +
                       "VALUES (?,?,?,?,?,?,?,?,?) ";

        try{
            Connection connection=DBUtils.getConnection();
            PreparedStatement psInsert = connection.prepareStatement(query);

            psInsert.setString(1,client.getNomClt());
            psInsert.setString(2,client.getPrenomClt());
            psInsert.setDate(3, Date.valueOf(client.getDateNaiss()));
            psInsert.setInt(4,client.getNumPermis());
            psInsert.setString(5,client.getAdressClt());
            psInsert.setInt(6,client.getTelClt());
            psInsert.setDate(7, Date.valueOf(client.getDateExprPermis()));
            psInsert.setDate(8, Date.valueOf(client.getDateDelivrPermis()));
            psInsert.setInt(9,0);

            int rs = psInsert.executeUpdate();




        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public static ObservableList<Client> getClients() {
        String query = """ 
        SELECT
            clt.idClt,
            clt.nomClt,
            clt.prenomClt,
            clt.dateNaiss,
            clt.adressClt,
            clt.telClt,
            sub.idContrat,
            sub.statutContrat
        FROM
            client clt
        LEFT JOIN (
            SELECT
                ctr.idClt,
                ctr.idContrat,
                ctr.statutContrat
            FROM
                contrat ctr
            WHERE
                ctr.idContrat = (
                    SELECT MAX(c.idContrat)
                    FROM contrat c
                    WHERE c.idClt = ctr.idClt
                )
        ) sub ON clt.idClt = sub.idClt;
    """;

        ObservableList<Client> clients = FXCollections.observableArrayList();
        try {
            Connection connection = DBUtils.getConnection();
            PreparedStatement psGet = connection.prepareStatement(query);
            ResultSet rs = psGet.executeQuery();

            while (rs.next()) {
                Client newClient = new Client();
                newClient.setIdClt(rs.getInt("idClt"));
                newClient.setNomClt(rs.getString("nomClt"));
                newClient.setPrenomClt(rs.getString("prenomClt"));
                newClient.setDateNaiss(rs.getDate("dateNaiss").toLocalDate());
                newClient.setAdressClt(rs.getString("adressClt"));
                newClient.setTelClt(rs.getInt("telClt"));

                Integer idContrat = rs.getObject("idContrat", Integer.class);
                Boolean statutContrat = rs.getObject("statutContrat", Boolean.class);

                if (idContrat != null && statutContrat != null) {

                    Contrat contrat = new Contrat();
                    contrat.setIdContrat(idContrat);
                    contrat.setStatutContrat(statutContrat);

                    List<Contrat> contrats = new ArrayList<>();
                    contrats.add(contrat);
                    newClient.setContrats(contrats);
                } else {

                    newClient.setContrats(new ArrayList<>());
                }

                clients.add(newClient);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return clients;
    }

    public static Client getClientDetails(int idClt) {
        String query = """
        SELECT
            idClt,
            nomClt,
            prenomClt,
            dateNaiss,
            numPermis,
            adressClt,
            telClt,
            dateExprPermis,
            dateDelivrPermis,
            supprimerClt
        FROM client
        WHERE idClt = ?;
    """;

        Client client = null;

        try {
            Connection connection = DBUtils.getConnection();
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idClt);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                client = new Client();
                client.setIdClt(rs.getInt("idClt"));
                client.setNomClt(rs.getString("nomClt"));
                client.setPrenomClt(rs.getString("prenomClt"));
                client.setDateNaiss(rs.getDate("dateNaiss").toLocalDate());
                client.setNumPermis(rs.getInt("numPermis"));
                client.setAdressClt(rs.getString("adressClt"));
                client.setTelClt(rs.getInt("telClt"));
                client.setDateExprPermis(rs.getDate("dateExprPermis").toLocalDate());
                client.setDateDelivrPermis(rs.getDate("dateDelivrPermis").toLocalDate());
                client.setSupprimerClt(rs.getBoolean("supprimerClt"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des détails du client", e);
        }

        return client;
    }

    public static void updateClient(Client client) {
        String query = """
        UPDATE client
        SET nomClt = ?, prenomClt = ?, dateNaiss = ?, numPermis = ?, adressClt = ?, 
            telClt = ?, dateExprPermis = ?, dateDelivrPermis = ?
        WHERE idClt = ?;
    """;

        try {
            Connection connection = DBUtils.getConnection();
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setString(1, client.getNomClt());
            ps.setString(2, client.getPrenomClt());
            ps.setDate(3, Date.valueOf(client.getDateNaiss()));
            ps.setInt(4, client.getNumPermis());
            ps.setString(5, client.getAdressClt());
            ps.setInt(6, client.getTelClt());
            ps.setDate(7, Date.valueOf(client.getDateExprPermis()));
            ps.setDate(8, Date.valueOf(client.getDateDelivrPermis()));
            ps.setInt(9, client.getIdClt());

            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du client", e);
        }
    }

    public static void deleteClient(int idClt) {
        String query = "DELETE FROM client WHERE idClt = ?";

        try {
            Connection connection = DBUtils.getConnection();
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idClt);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du client", e);
        }
    }

    public static void softDeleteClient(int idClt) {
        String query = "UPDATE client SET supprimerClt = 1 WHERE idClt = ?";

        try {
            Connection connection = DBUtils.getConnection();
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idClt);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors du soft delete du client", e);
        }
    }

    public static List<Contrat> getHistoriqueContratsParClient(int clientId) {
        List<Contrat> contrats = new ArrayList<>();
        String query = "SELECT idContrat, debContrat, finContrat, prixContrat " +
                "FROM contrat " +
                "WHERE idClt = ? AND contrat.supprimerCtr =0";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, clientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Contrat contrat = new Contrat();
                contrat.setIdContrat(rs.getInt("idContrat"));
                contrat.setDebContrat(rs.getTimestamp("debContrat").toLocalDateTime());
                contrat.setFinContrat(rs.getTimestamp("finContrat").toLocalDateTime());
                contrat.setPrixContrat(rs.getInt("prixContrat"));
                contrats.add(contrat);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contrats;
    }

}
