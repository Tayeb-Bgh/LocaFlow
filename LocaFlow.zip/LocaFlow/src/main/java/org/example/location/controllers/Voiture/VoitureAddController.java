package org.example.location.controllers.Voiture;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.dbUtils.VoitureDao;
import org.example.location.models.Suivie;
import org.example.location.models.Vehicule;

import java.time.LocalDate;

public class VoitureAddController {
    @FXML
    private TextField chassisField;

    @FXML
    private TextField matriculeField;

    @FXML
    private TextField marqueField;

    @FXML
    private TextField modeleField;

    @FXML
    private TextField couleurField;

    @FXML
    private TextField carteGriseField;

    @FXML
    private ComboBox<String> energieComboBox;

    @FXML
    private TextField controleTechField;

    @FXML
    private TextField assuranceField;

    @FXML
    private TextField vidangeField;

    @FXML
    private TextField kilometrageField;

    private Vehicule currentVehicle;
    private Stage stage;
    private boolean saveClicked = false;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public void setEditMode(Vehicule vehicle) {


        matriculeField.setText(vehicle.getMatriculeVeh());
        marqueField.setText(vehicle.getMarqueVeh());
        modeleField.setText(vehicle.getModeleVeh());
        chassisField.setText(vehicle.getNumChassisVeh());
        couleurField.setText(vehicle.getCouleurVeh());
        carteGriseField.setText(vehicle.getCarteGriseVeh());
        energieComboBox.setValue(vehicle.getEnergieVeh());
        kilometrageField.setText(String.valueOf(vehicle.getKilometrage()));

        if (!vehicle.getSuivies().isEmpty()) {
            Suivie suivie = vehicle.getSuivies().get(0);
            controleTechField.setText(suivie.getControleTechExp().toString());
            assuranceField.setText(suivie.getAssuranceExp().toString());
            vidangeField.setText(String.valueOf(suivie.getVidangeExp()));
        }
        currentVehicle = vehicle;
    }

    public Vehicule getNewVehicle() {
        Vehicule newVehicule = new Vehicule();
        newVehicule.setMatriculeVeh(matriculeField.getText());
        newVehicule.setModeleVeh(modeleField.getText());
        newVehicule.setMarqueVeh(marqueField.getText());
        newVehicule.setNumChassisVeh(chassisField.getText());
        newVehicule.setCouleurVeh(couleurField.getText());
        newVehicule.setCarteGriseVeh(carteGriseField.getText());
        newVehicule.setEnergieVeh(energieComboBox.getValue());
        newVehicule.setKilometrage(Integer.parseInt(kilometrageField.getText()));

        Suivie suivie = new Suivie();
        suivie.setControleTechExp(LocalDate.parse(controleTechField.getText()));
        suivie.setAssuranceExp(LocalDate.parse(assuranceField.getText()));
        suivie.setVidangeExp(Integer.parseInt(vidangeField.getText()));

        newVehicule.ajouterSuivie(suivie);
        return newVehicule;
    }

    @FXML
    public void handleSave(ActionEvent event) {

        Vehicule vehicule = new Vehicule();
        if (isInputValid()==false) {
            return;
        }
        vehicule.setIdVeh(currentVehicle != null ? currentVehicle.getIdVeh() : 0);
        vehicule.setMatriculeVeh(matriculeField.getText());
        vehicule.setMarqueVeh(marqueField.getText());
        vehicule.setModeleVeh(modeleField.getText());
        vehicule.setNumChassisVeh(chassisField.getText());
        vehicule.setCouleurVeh(couleurField.getText());
        vehicule.setCarteGriseVeh(carteGriseField.getText());
        vehicule.setEnergieVeh(energieComboBox.getValue());
        vehicule.setKilometrage(Integer.parseInt(kilometrageField.getText()));

        Suivie suivie = new Suivie();
        suivie.setControleTechExp(LocalDate.parse(controleTechField.getText()));
        suivie.setAssuranceExp(LocalDate.parse(assuranceField.getText()));
        suivie.setVidangeExp(Integer.parseInt(vidangeField.getText()));

        vehicule.ajouterSuivie(suivie);

        if (currentVehicle != null) {
            VoitureDao.updateVehicle(vehicule);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Vehicule modifié avec succès.");
            alert.showAndWait();

        } else {
            VoitureDao.addVehicle(vehicule);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Vehicule ajouté avec succès.");
            alert.showAndWait();
        }

        if (stage != null) {
            stage.close();
        }
    }

    @FXML
    public void handleCancel(ActionEvent event) {
        if (stage != null) {
            stage.close();
        }
    }

    private boolean isInputValid() {
        StringBuilder errorMessage = new StringBuilder();

        if (marqueField.getText() == null || marqueField.getText().isEmpty()) {
            errorMessage.append("La marque est obligatoire.\n");
        }
        if (modeleField.getText() == null || modeleField.getText().isEmpty()) {
            errorMessage.append("Le modèle est obligatoire.\n");
        }
        if (matriculeField.getText() == null || matriculeField.getText().isEmpty()) {
            errorMessage.append("Le matricule est obligatoire.\n");
        }
        if (chassisField.getText() == null || chassisField.getText().isEmpty()) {
            errorMessage.append("Le numéro de chassis est obligatoire.\n");
        }
        if (couleurField.getText() == null || couleurField.getText().isEmpty()) {
            errorMessage.append("La couleur est obligatoire.\n");
        }
        if (carteGriseField.getText() == null || carteGriseField.getText().isEmpty()) {
            errorMessage.append("Le numéro de carte grise est obligatoire.\n");
        }
        if (energieComboBox.getValue() == null) {
            errorMessage.append("L'energie est obligatoire.\n");
        }
        if (kilometrageField.getText() == null || kilometrageField.getText().isEmpty()) {
            errorMessage.append("Le kilometrage est obligatoire.\n");
        }
        if (controleTechField.getText() == null || controleTechField.getText().isEmpty()) {
            errorMessage.append("La date de controle technique est obligatoire.\n");
        }
        if (assuranceField.getText() == null || assuranceField.getText().isEmpty()) {
            errorMessage.append("La date d'assurance est obligatoire.\n");
        }
        if (vidangeField.getText() == null || vidangeField.getText().isEmpty()) {
            errorMessage.append("Le kilometrage de vidange est obligatoire.\n");
        }
        if (Integer.parseInt(kilometrageField.getText()) < 0 || Integer.parseInt(vidangeField.getText()) < 0) {
            errorMessage.append("Le kilometrage doit etre superieur a 0.\n");
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Champs invalides");
            alert.setHeaderText("Corrigez les champs suivants :");
            alert.setContentText(errorMessage.toString());
            alert.showAndWait();
            return false;
        }
    }
}
