package org.example.location.controllers.Voiture;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.dbUtils.VoitureDao;
import org.example.location.models.Maintenance;

import java.time.LocalDate;

public class MaintenanceAddController {

    @FXML private TextField idVehField;
    @FXML private DatePicker debMaintenancePicker;
    @FXML private DatePicker finMaintenancePicker;
    @FXML private TextField prixMaintenanceField;
    @FXML private Button addButton;
    @FXML private Button cancelButton;

    private int currentVehId;

    public void setVehId(int id) {
        this.currentVehId = id;


        idVehField.setText(String.valueOf(currentVehId));
        idVehField.setEditable(false);


        debMaintenancePicker.setValue(LocalDate.now());
        debMaintenancePicker.setDisable(true);
    }

    @FXML
    public void handleAdd(ActionEvent event) {
        try {
            // Validation des champs
            LocalDate dateDebut = debMaintenancePicker.getValue();
            LocalDate dateFin = finMaintenancePicker.getValue();
            String prixText = prixMaintenanceField.getText();

            if (dateFin == null || prixText.isEmpty()) {
                showAlert("Erreur", "Veuillez remplir tous les champs requis.");
                return;
            }

            double prixMaintenance;
            try {
                prixMaintenance = Double.parseDouble(prixText);
            } catch (NumberFormatException e) {
                showAlert("Erreur de saisie", "Le prix doit être un nombre valide.");
                return;
            }

            if (dateFin.isBefore(dateDebut)) {
                showAlert("Erreur de date", "La date de fin ne peut pas être avant la date de début.");
                return;
            }


            Maintenance maintenance = new Maintenance();
            maintenance.setIdVeh(currentVehId);
            maintenance.setDebMaintenance(dateDebut);
            maintenance.setFinMaintenance(dateFin);
            maintenance.setPrixMaintenance((int) prixMaintenance);


            VoitureDao.addMaintenance(maintenance);

            showAlert("Succès", "Maintenance ajoutée avec succès!");


            handleCancel(event);

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Une erreur s'est produite lors de l'ajout de la maintenance.");
        }
    }

    @FXML
    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
