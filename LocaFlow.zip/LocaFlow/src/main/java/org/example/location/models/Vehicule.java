package org.example.location.models;

import java.util.ArrayList;
import java.util.List;

public class Vehicule {

    private int idVeh;
    private String matriculeVeh;
    private String modeleVeh;
    private String marqueVeh;
    private String numChassisVeh;
    private String couleurVeh;
    private String carteGriseVeh;
    private String energieVeh;

    public int getKilometrage() {
        return kilometrage;
    }

    public void setKilometrage(int kilometrage) {
        this.kilometrage = kilometrage;
    }

    private int kilometrage;
    private Boolean supprimerVeh;

    private List<Maintenance> maintenances = new ArrayList<>();
    private List<Contrat> contrats = new ArrayList<>();
    private List<Suivie> suivies = new ArrayList<>();
    private String statutVeh;

    public Vehicule(String marqueVeh, String modeleVeh) {
        this.marqueVeh = marqueVeh;
        this.modeleVeh= modeleVeh;
    }

    public Vehicule(int idVeh, String marqueVeh, String modeleVeh, String energieVeh) {
        this.idVeh = idVeh;
        this.marqueVeh = marqueVeh;
        this.modeleVeh = modeleVeh;
        this.energieVeh = energieVeh;
    }

    public Vehicule() {

    }
    public void addMaintenance(Maintenance maintenance) {
        if (this.maintenances == null) {
            this.maintenances = new ArrayList<>();
        }
        this.maintenances.add(maintenance);
    }


    public Contrat getContratActuel() {
        return contratActuel;
    }

    public void setContratActuel(Contrat contratActuel) {
        this.contratActuel = contratActuel;
    }

    private Contrat contratActuel;




    public void ajouterSuivie(Suivie suivie) {
        if (suivie != null) {
            this.suivies.add(suivie);
        } else {
            throw new IllegalArgumentException("L'objet Suivie ne peut pas être null.");
        }
    }

    // Getters et setters
    public int getIdVeh() {
        return idVeh;
    }

    public void setIdVeh(int idVeh) {
        this.idVeh = idVeh;
    }

    public String getMatriculeVeh() {
        return matriculeVeh;
    }

    public void setMatriculeVeh(String matriculeVeh) {
        this.matriculeVeh = matriculeVeh;
    }

    public String getModeleVeh() {
        return modeleVeh;
    }

    public void setModeleVeh(String modeleVeh) {
        this.modeleVeh = modeleVeh;
    }

    public String getMarqueVeh() {
        return marqueVeh;
    }

    public void setMarqueVeh(String marqueVeh) {
        this.marqueVeh = marqueVeh;
    }

    public String getNumChassisVeh() {
        return numChassisVeh;
    }

    public void setNumChassisVeh(String numChassisVeh) {
        this.numChassisVeh = numChassisVeh;
    }

    public String getCouleurVeh() {
        return couleurVeh;
    }

    public void setCouleurVeh(String couleurVeh) {
        this.couleurVeh = couleurVeh;
    }

    public String getCarteGriseVeh() {
        return carteGriseVeh;
    }

    public void setCarteGriseVeh(String carteGriseVeh) {
        this.carteGriseVeh = carteGriseVeh;
    }

    public String getEnergieVeh() {
        return energieVeh;
    }

    public void setEnergieVeh(String energieVeh) {
        this.energieVeh = energieVeh;
    }

    public Boolean getSupprimerVeh() {
        return supprimerVeh;
    }

    public void setSupprimerVeh(Boolean supprimerVeh) {
        this.supprimerVeh = supprimerVeh;
    }

    public String getStatutVeh() {
        return statutVeh;
    }

    public void setStatutVeh(String statutVeh) {
        this.statutVeh = statutVeh;
    }

    public List<Maintenance> getMaintenances() {
        return maintenances;
    }

    public void setMaintenances(List<Maintenance> maintenances) {
        this.maintenances = maintenances;
    }

    public List<Contrat> getContrats() {
        return contrats;
    }

    public void setContrats(List<Contrat> contrats) {
        this.contrats = contrats;
    }

    public List<Suivie> getSuivies() {
        return suivies;
    }

    public void setSuivies(List<Suivie> suivies) {
        this.suivies = suivies;
    }

    public void ajouterMaintenance(Maintenance maintenance) {
        if (maintenance != null) {
            this.maintenances.add(maintenance);
        }

    }
}
