package org.example.location.controllers.Client;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;
import org.example.location.HelloApplication;
import org.example.location.controllers.Switch;
import org.example.location.dbUtils.ClientDAO;
import org.example.location.models.Client;
import javafx.stage.Stage;
import javafx.stage.Modality;
import javafx.scene.Scene;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;


import javafx.scene.control.*;

import javafx.geometry.Pos;
import org.example.location.models.Contrat;


public class ClientController {
   
    public Label totalClientsLabel;
    public Label clientsReservationLabel;
    public Label clientsNoContractLabel;
    @FXML
    private ComboBox<String> filterComboBox;
    @FXML
    private TextField searchField;

    private ObservableList<Contrat> loadReservationsForClient(int clientId) {
        ObservableList<Contrat> contrats = FXCollections.observableArrayList();
        // TODO: Load actual reservations from your database
        return contrats;
    }

    @FXML
    private TableView<Client> clientsTable;

    @FXML
    private TableColumn<Client, Integer> idColumn;

    @FXML
    private TableColumn<Client, String> nomColumn;

    @FXML
    private TableColumn<Client, String> prenomColumn;

    @FXML
    private TableColumn<Client, LocalDate> dateNaissanceColumn;

    @FXML
    private TableColumn<Client, String> adressColumn;

    @FXML
    private TableColumn<Client, Integer> telephoneColumn;

    @FXML
    private TableColumn<Client, String> statutColumn;

    @FXML
    private TableColumn<Client, Void> actionColumn;

    private ObservableList<Client> clientsList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {

        idColumn.setCellValueFactory(new PropertyValueFactory<>("idClt"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nomClt"));

        prenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenomClt"));
        dateNaissanceColumn.setCellValueFactory(new PropertyValueFactory<>("dateNaiss"));
        adressColumn.setCellValueFactory(new PropertyValueFactory<>("adressClt"));
        telephoneColumn.setCellValueFactory(new PropertyValueFactory<>("telClt"));
        statutColumn.setCellValueFactory(cellData -> {
            Boolean statut = cellData.getValue().getLastContratStatut();
            return new SimpleStringProperty(statut == null ? "Rien" : statut ? "Terminé" : "En cours");
        });


        filterComboBox.setItems(FXCollections.observableArrayList("Nom", "Prénom", "Téléphone"));
        filterComboBox.getSelectionModel().selectFirst();

        setupActionColumn();
        loadClients();
    }


    private void setupActionColumn() {
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final FontAwesomeIconView editIcon = new FontAwesomeIconView(FontAwesomeIcon.EDIT);
            private final FontAwesomeIconView deleteIcon = new FontAwesomeIconView(FontAwesomeIcon.TRASH);
            private final FontAwesomeIconView viewIcon = new FontAwesomeIconView(FontAwesomeIcon.EYE);

            {

                editIcon.setStyleClass("action-icon");
                deleteIcon.setStyleClass("action-icon");
                viewIcon.setStyleClass("action-icon");

                editIcon.setOnMouseClicked(event -> {
                    try {
                        handleEditAction(getTableView().getItems().get(getIndex()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });

                deleteIcon.setOnMouseClicked(event -> handleDeleteAction(getTableView().getItems().get(getIndex())));

                viewIcon.setOnMouseClicked(event -> {
                    try {
                        handleViewDetails(event);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });

                editIcon.setSize("1.8em");
                deleteIcon.setSize("1.8em");
                viewIcon.setSize("1.8em");
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox container = new HBox(10, editIcon, deleteIcon, viewIcon);
                    container.setAlignment(Pos.CENTER);
                    setGraphic(container);
                }
            }
        });
    }



    @FXML
    private void handleVehicules(MouseEvent event){
        Switch.changeScene(event,"view/Voiture/voiture-view.fxml");
    }

    @FXML
    private void handleLocations(MouseEvent event){
        Switch.changeScene(event,"view/Location/location-view.fxml");
    }

    @FXML
    private void handlePaiements(MouseEvent event){
        Switch.changeScene(event,"view/Paiement/paiement-view.fxml");
    }

    @FXML
    private void handleDashboard(MouseEvent event){
        Switch.changeScene(event,"view/Dashboard/dashboard-view.fxml");
    }

    @FXML
    private void handleClient(){

    }
    @FXML
    public void handleEmploye(MouseEvent event) {
        if (HelloApplication.permission == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Accès refusé");
            alert.setHeaderText("Accès refusé");
            alert.setContentText("Vous devez avoir un compte admin pour acceder au menu Employé");
            alert.showAndWait();
            return;
        }
        Switch.changeScene(event, "view/Employe/employe-view.fxml");
    }

    @FXML
    private void handleAddClient() {
        try {
            // Charger le FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Client/client-add-view.fxml"));
            AnchorPane page = loader.load();

            // Créer la fenêtre de dialogue
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Ajouter un client");
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.initStyle(StageStyle.UNDECORATED);

            // Configurer la scène
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Obtenir le contrôleur et définir le stage
            ClientAddController controller = loader.getController();
            controller.setStage(dialogStage);

            // Ajouter l'effet de flou sur la fenêtre principale
            Scene mainScene = clientsTable.getScene();
            HBox root = (HBox) mainScene.getRoot();

            // Créer l'overlay
            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);

            // Appliquer le flou
            GaussianBlur blur = new GaussianBlur(10);
            root.getChildren().add(overlay);
            root.setEffect(blur);

            // Restaurer l'état normal lors de la fermeture
            dialogStage.setOnHidden(e -> {
                root.getChildren().remove(overlay);
                root.setEffect(null);

                // Si l'utilisateur a cliqué sur Enregistrer
                if (controller.isSaveClicked()) {
                    Client newClient = controller.getNewClient();
                    ClientDAO.insertClient(newClient);
                    loadClients();


                }
            });

            // Afficher la fenêtre de dialogue
            dialogStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Erreur lors de l'ouverture du formulaire d'ajout de client.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleEditAction(Client client) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Client/client-add-view.fxml"));
        AnchorPane page = loader.load();

        Stage dialogStage = new Stage();
        dialogStage.setTitle("Modifier un client");
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.initStyle(StageStyle.UNDECORATED);
        dialogStage.setScene(new Scene(page));

        ClientAddController controller = loader.getController();
        controller.setClientToEdit(ClientDAO.getClientDetails(client.getIdClt()) );
        controller.setStage(dialogStage);


        Scene mainScene = clientsTable.getScene();
        HBox root = (HBox) mainScene.getRoot();


        Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
        overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
        overlay.setManaged(false);
        overlay.setMouseTransparent(true);


        GaussianBlur blur = new GaussianBlur(10);
        root.getChildren().add(overlay);
        root.setEffect(blur);

        dialogStage.setOnHidden(e -> {
            root.getChildren().remove(overlay);
            root.setEffect(null);
        });


        dialogStage.showAndWait();

        if (controller.isSaveClicked()) {
            loadClients();
        }
    }




    @FXML
    private void handleDeleteAction(Client client) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText(null);
        alert.setContentText("Etes-vous sur de vouloir supprimer ce client ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (client.getContrats() != null && !client.getContrats().isEmpty()) {

                ClientDAO.softDeleteClient(client.getIdClt());
            } else {

                ClientDAO.deleteClient(client.getIdClt());
            }
            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Le client a été supprimé avec succès.");
            alert.showAndWait();
        }


        loadClients();
    }




    private void loadClients() {
        clientsList = ClientDAO.getClients();
        clientsTable.setItems(clientsList);
        clientsTable.refresh();


        long totalClients = clientsList.size();


        long clientsWithReservations = clientsList.stream()
                .filter(client -> client.getContrats() != null
                        && client.getContrats().stream().anyMatch(contrat -> !contrat.getStatutContrat()))
                .count();


        long clientsWithoutContracts = clientsList.stream()
                .filter(client -> client.getContrats() == null
                        || client.getContrats().isEmpty()
                        || client.getContrats().stream().allMatch(contrat -> contrat.getStatutContrat()))
                .count();


        totalClientsLabel.setText(String.valueOf(totalClients));
        clientsReservationLabel.setText(String.valueOf(clientsWithReservations));
        clientsNoContractLabel.setText(String.valueOf(clientsWithoutContracts));
    }

    @FXML
    public void handleViewDetails(MouseEvent event) throws IOException {

        Client selectedClient = clientsTable.getSelectionModel().getSelectedItem();
        if (selectedClient == null) return;


        Client detailedClient = ClientDAO.getClientDetails(selectedClient.getIdClt());


        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Client/client-details-view.fxml"));
        Scene modalScene = new Scene(loader.load(), 800, 600);


        ClientDetailsController controller = loader.getController();
        controller.setClientDetails(detailedClient);


        Stage modalStage = new Stage();
        modalStage.initModality(Modality.APPLICATION_MODAL);
        modalStage.initStyle(StageStyle.UNDECORATED);
        modalStage.setScene(modalScene);


        Scene mainScene = clientsTable.getScene();
        HBox root = (HBox) mainScene.getRoot();


        Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
        overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
        overlay.setManaged(false);
        overlay.setMouseTransparent(true);


        GaussianBlur blur = new GaussianBlur(10);
        root.getChildren().add(overlay);
        root.setEffect(blur);


        modalStage.setOnHidden(e -> {
            root.getChildren().remove(overlay);
            root.setEffect(null);
        });


        modalStage.showAndWait();
    }


    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().toLowerCase();
        String filterBy = (String) filterComboBox.getSelectionModel().getSelectedItem();

        if (searchTerm.isEmpty()) {

            loadClients();
            return;
        }


        ObservableList<Client> filteredClients = clientsList.filtered(client -> {
            switch (filterBy) {
                case "Nom":
                    return client.getNomClt().toLowerCase().contains(searchTerm);
                case "Prénom":
                    return client.getPrenomClt().toLowerCase().contains(searchTerm);
                case "Téléphone":
                    return String.valueOf(client.getTelClt()).contains(searchTerm);
                default:
                    return false;
            }
        });


        clientsTable.setItems(filteredClients);
    }

    @FXML
    private void handleFilterChange() {
        handleSearch();
    }


    @FXML
    private void filterTotalClients() {

        clientsTable.setItems(clientsList);

        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }


    @FXML
    private void filterClientsWithReservation() {
        ObservableList<Client> filteredClients = clientsList.filtered(client -> {
            if (client.getContrats() == null || client.getContrats().isEmpty()) {
                return false;
            }
            return client.getContrats().stream().anyMatch(contrat -> !contrat.getStatutContrat());
        });

        clientsTable.setItems(filteredClients);

        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }

    @FXML
    private void filterClientsWithoutContracts() {
        ObservableList<Client> filteredClients = clientsList.filtered(client -> {
            if (client.getContrats() == null || client.getContrats().isEmpty()) {
                return true;
            }
            // Vérifie si tous les contrats sont terminés
            return client.getContrats().stream().allMatch(contrat -> contrat.getStatutContrat());
        });

        clientsTable.setItems(filteredClients);

        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }

    @FXML
    private void handleOpenAgenceDetails() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Agence/agence-view.fxml"));
            Scene scene = new Scene(loader.load());
            Stage modalStage = new Stage();
            modalStage.initModality(Modality.APPLICATION_MODAL);
            modalStage.setTitle("Détails de l'Agence");
            modalStage.setScene(scene);
            modalStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
