package org.example.location.dbUtils;

import org.example.location.models.Client;
import org.example.location.models.Contrat;
import org.example.location.models.Vehicule;

import java.sql.*;
import java.util.*;
import java.util.Date;
import java.util.stream.Collectors;

public class DashboardDao {

    // Configuration de la connexion à la base de données

    public static Map<String, Double> getRevenusMensuels() {
        Map<String, Double> revenus = new LinkedHashMap<>();
        String query = "SELECT MONTHNAME(debContrat) AS mois, SUM(prixContrat) AS montant " +
                "FROM contrat WHERE statutContrat = 1 GROUP BY MONTH(debContrat)";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                revenus.put(rs.getString("mois"), rs.getDouble("montant"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return revenus;
    }

    /**
     * Méthode pour récupérer les notifications.
     * @return Liste de chaînes représentant les notifications.
     */
    public static List<String> getNotifications() {
        List<String> notifications = new ArrayList<>();

        String query = """
        SELECT v.marqueVeh, v.modeleVeh, v.kilometrage,
               s.assuranceExp, s.controleTechExp, s.vidangeExp
        FROM vehicule v
        LEFT JOIN suivie s ON v.idVeh = s.idVeh
        WHERE v.supprimerVeh = 0
          AND (
              (s.assuranceExp IS NOT NULL AND (s.assuranceExp <= CURDATE() OR s.assuranceExp BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
              OR
              (s.controleTechExp IS NOT NULL AND (s.controleTechExp <= CURDATE() OR s.controleTechExp BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)))
              OR
              (v.kilometrage - s.vidangeExp >= 20000)
          )
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String marque = rs.getString("marqueVeh");
                String modele = rs.getString("modeleVeh");

                Date assuranceExp = rs.getDate("assuranceExp");
                Date controleExp = rs.getDate("controleTechExp");
                int kilometrage = rs.getInt("kilometrage");
                int vidangeKm = rs.getInt("vidangeExp");

                // Assurance expirée ou proche d'expiration
                if (assuranceExp != null) {
                    if (assuranceExp.before(java.sql.Date.valueOf(java.time.LocalDate.now()))) {
                        notifications.add("Assurance expirée pour la voiture '" + marque + " " + modele + "'.");
                    } else if (assuranceExp.before(java.sql.Date.valueOf(java.time.LocalDate.now().plusDays(7)))) {
                        notifications.add("Assurance bientôt expirée pour la voiture '" + marque + " " + modele + "'.");
                    }
                }

                // Contrôle technique expiré ou proche d'expiration
                if (controleExp != null) {
                    if (controleExp.before(java.sql.Date.valueOf(java.time.LocalDate.now()))) {
                        notifications.add("Contrôle technique expiré pour la voiture '" + marque + " " + modele + "'.");
                    } else if (controleExp.before(java.sql.Date.valueOf(java.time.LocalDate.now().plusDays(7)))) {
                        notifications.add("Contrôle technique bientôt expiré pour la voiture '" + marque + " " + modele + "'.");
                    }
                }

                // Vidange nécessaire si (kilometrage - vidangeExp >= 20000)
                if (vidangeKm > 0 && (kilometrage - vidangeKm) >= 20000) {
                    notifications.add("Vidange nécessaire pour la voiture '" + marque + " " + modele + "' (parcours depuis la dernière vidange : "
                            + (kilometrage - vidangeKm) + " km).");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return notifications;
    }




    /**
     * Méthode pour récupérer les contrats finissant aujourd'hui.
     * @return Liste des contrats finissant aujourd'hui.
     */
    public static List<Contrat> getContratsFinissantAujourdhui() {
        List<Contrat> contrats = new ArrayList<>();
        String query = "SELECT c.idContrat, c.finContrat, cl.nomClt, cl.prenomClt, v.marqueVeh, v.modeleVeh " +
                "FROM contrat c " +
                "JOIN client cl ON c.idClt = cl.idClt " +
                "JOIN vehicule v ON c.idVeh = v.idVeh " +
                "WHERE DATE(c.finContrat) = CURDATE()";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Contrat contrat = new Contrat();
                contrat.setIdContrat(rs.getInt("idContrat"));
                contrat.setFinContrat(rs.getDate("finContrat").toLocalDate().atStartOfDay());

                // Instanciation et remplissage du client
                Client client = new Client();
                client.setNomClt(rs.getString("nomClt"));
                client.setPrenomClt(rs.getString("prenomClt"));
                contrat.setClient(client);

                // Instanciation et remplissage du véhicule
                Vehicule vehicule = new Vehicule();
                vehicule.setMarqueVeh(rs.getString("marqueVeh"));
                vehicule.setModeleVeh(rs.getString("modeleVeh"));
                contrat.setVehicule(vehicule);

                // Ajout du contrat rempli à la liste
                contrats.add(contrat);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contrats;
    }

    /**
     * Méthode pour récupérer les véhicules disponibles.
     * @return Liste des véhicules disponibles.
     */
    public static List<Vehicule> getVehiculesDisponibles() {
        List<Vehicule> list = VoitureDao.fetchAllVehicles().stream().filter(v -> v.getStatutVeh()=="Disponible").collect(Collectors.toList());
        return list;
//        List<Vehicule> vehicules = new ArrayList<>();
//        String query = "SELECT idVeh, marqueVeh, modeleVeh, energieVeh FROM vehicule WHERE supprimerVeh = 0";
//
//        try (Connection conn = DBUtils.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(query);
//             ResultSet rs = stmt.executeQuery()) {
//
//            while (rs.next()) {
//                Vehicule vehicule = new Vehicule(
//                        rs.getInt("idVeh"),
//                        rs.getString("marqueVeh"),
//                        rs.getString("modeleVeh"),
//                        rs.getString("energieVeh")
//                );
//                vehicules.add(vehicule);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return vehicules;
    }

    /**
     * Méthode pour récupérer le nombre de contrats en cours.
     * @return Nombre de contrats actifs.
     */
    public static int getNombreContratsEnCours() {
        String query = "SELECT COUNT(*) AS total FROM contrat WHERE statutContrat = 0";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Méthode pour récupérer le nombre de véhicules disponibles.
     * @return Nombre de véhicules disponibles.
     */
    public static int getNombreVehiculesDisponibles() {
        List<Vehicule> list = VoitureDao.fetchAllVehicles().stream().filter(v -> v.getStatutVeh()=="Disponible").collect(Collectors.toList());
        return list.size();
//        String query = "SELECT COUNT(*) AS total FROM vehicule WHERE supprimerVeh = 0";
//        try (Connection conn = DBUtils.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(query);
//             ResultSet rs = stmt.executeQuery()) {
//
//            if (rs.next()) {
//                return rs.getInt("total");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return 0;
    }

    /**
     * Méthode pour récupérer le nombre de contrats finissant aujourd'hui.
     * @return Nombre de contrats finissant aujourd'hui.
     */
    public static int getNombreContratsFinissantAujourdhui() {
        String query = "SELECT COUNT(*) AS total FROM contrat WHERE DATE(finContrat) = CURDATE()";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Méthode pour récupérer le nombre total de clients.
     * @return Nombre de clients.
     */
    public static int getNombreClients() {
        String query = "SELECT COUNT(*) AS total FROM client";
        try (Connection conn =DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
