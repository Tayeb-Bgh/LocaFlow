package org.example.location.dbUtils;

import org.example.location.HelloApplication;
import org.example.location.models.Contrat;
import org.example.location.models.Employe;
import org.example.location.models.Prolongation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.List;

public class LocationDao {
    public static void validateLocation(int contratId) {
        String query = "UPDATE contrat SET statutContrat = 1 WHERE idContrat = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, contratId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Contrat getContratById(int contratId) {
        Contrat contrat = null;
        String query = """
        SELECT 
            c.idContrat, 
            cl.nomClt, 
            cl.prenomClt, 
            v.marqueVeh, 
            v.modeleVeh, 
            c.debContrat, 
            c.finContrat, 
            c.prixContrat, 
            c.cautionContrat, 
            c.statutContrat,
            e.prenomEmp,
            e.nomEmp
        FROM contrat c
        JOIN client cl ON c.idClt = cl.idClt
        JOIN vehicule v ON c.idVeh = v.idVeh
        JOIN employe e ON e.idEmp = c.idEmp
        WHERE c.idContrat = ?
    """;

        Employe employe = new Employe();

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, contratId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                contrat = new Contrat();
                contrat.setIdContrat(rs.getInt("idContrat"));
                contrat.setNomClient(rs.getString("nomClt") + " " + rs.getString("prenomClt"));
                contrat.setNomVehicule(rs.getString("marqueVeh") + " " + rs.getString("modeleVeh"));
                contrat.setDebContrat(rs.getTimestamp("debContrat").toLocalDateTime());
                contrat.setFinContrat(rs.getTimestamp("finContrat").toLocalDateTime());
                contrat.setPrixContrat(rs.getDouble("prixContrat"));
                contrat.setCautionContrat(rs.getDouble("cautionContrat"));
                contrat.setStatutContrat(rs.getInt("statutContrat") == 1);
                employe.setNomEmp(rs.getString("nomEmp"));
                employe.setPrenomEmp(rs.getString("prenomEmp"));

                contrat.setEmploye(employe);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contrat;
    }


    public static void addLocation(Contrat contrat) {
        String query = """
            INSERT INTO contrat (idClt, idVeh,idEmp, debContrat, finContrat, prixContrat, cautionContrat, statutContrat)
            VALUES (?, ?,?, ?, ?, ?, ?, 0)
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, contrat.getIdClient());
            ps.setInt(2, contrat.getIdVehicule());
            ps.setInt(3, HelloApplication.idEmploye);
            ps.setDate(4, java.sql.Date.valueOf(contrat.getDebContrat().toLocalDate()));
            ps.setDate(5, java.sql.Date.valueOf(contrat.getFinContrat().toLocalDate()));
            ps.setDouble(6, contrat.getPrixContrat());
            ps.setDouble(7, contrat.getCautionContrat());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<String> getAvailableClients() {
        List<String> clients = new ArrayList<>();
        String query = """
            SELECT c.idClt, c.nomClt, c.prenomClt
            FROM client c
            WHERE c.idClt NOT IN (
                SELECT DISTINCT idClt 
                FROM contrat 
                WHERE statutContrat = 0
            ) AND c.supprimerClt = 0
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int idClient = rs.getInt("idClt");
                String fullName = rs.getString("nomClt") + " " + rs.getString("prenomClt");
                clients.add(idClient + " - " + fullName); // Display format: "ID - Full Name"
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return clients;
    }

    public static List<String> getAvailableVehicles() {
        List<String> vehicles = new ArrayList<>();
        String query = """
        SELECT v.idVeh, v.marqueVeh, v.modeleVeh
        FROM vehicule v
        LEFT JOIN (
            SELECT DISTINCT idVeh
            FROM contrat
            WHERE statutContrat = 0
        ) c ON v.idVeh = c.idVeh
        LEFT JOIN (
            SELECT DISTINCT idVeh
            FROM maintenance
            WHERE finMaintenance >= CURDATE()
        ) m ON v.idVeh = m.idVeh
        WHERE c.idVeh IS NULL -- Pas en location
          AND m.idVeh IS NULL -- Pas en maintenance
          AND v.supprimerVeh = 0; -- Véhicule non supprimé
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int idVehicle = rs.getInt("idVeh");
                String vehicleName = rs.getString("marqueVeh") + " " + rs.getString("modeleVeh");
                vehicles.add(idVehicle + " - " + vehicleName); // Format: "ID - Marque Modèle"
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehicles;
    }

    public static List<Contrat> fetchAllLocations() {
        List<Contrat> locations = new ArrayList<>();
        String query = """
        SELECT 
            c.idContrat, 
            cl.nomClt, 
            cl.prenomClt, 
            v.marqueVeh, 
            v.modeleVeh, 
            c.debContrat, 
            c.finContrat, 
            c.prixContrat, 
            c.cautionContrat, 
            c.statutContrat
        FROM contrat c
        JOIN client cl ON c.idClt = cl.idClt
        JOIN vehicule v ON c.idVeh = v.idVeh WHERE c.supprimerCtr =0 OR c.supprimerCtr IS NULL
    """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Contrat contrat = new Contrat();
                contrat.setIdContrat(rs.getInt("idContrat"));

                // Concaténation du nom et prénom du client
                String clientName = rs.getString("nomClt") + " " + rs.getString("prenomClt");
                contrat.setNomClient(clientName);

                // Concaténation de la marque et du modèle du véhicule
                String vehicleName = rs.getString("marqueVeh") + " " + rs.getString("modeleVeh");
                contrat.setNomVehicule(vehicleName);

                contrat.setDebContrat(rs.getTimestamp("debContrat").toLocalDateTime());
                contrat.setFinContrat(rs.getTimestamp("finContrat").toLocalDateTime());
                contrat.setPrixContrat(rs.getDouble("prixContrat"));
                contrat.setCautionContrat(rs.getDouble("cautionContrat"));
                contrat.setStatutContrat(rs.getBoolean("statutContrat"));

                locations.add(contrat);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return locations;
    }

    public static void updateVehicleKilometrage(int idVeh, int nouveauKilometrage) {
        String query = "UPDATE vehicule SET kilometrage = ? WHERE idVeh = ?";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, nouveauKilometrage);
            ps.setInt(2, idVeh);

            ps.executeUpdate();
            System.out.println("Kilométrage mis à jour pour le véhicule ID: " + idVeh);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Prolongation> getProlongationsByContratId(int contratId) {
        List<Prolongation> prolongations = new ArrayList<>();
        String query = """
            SELECT finProlonge, prixProlonge
            FROM prolongation
            WHERE idContrat = ?
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, contratId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Prolongation prolongation = new Prolongation();
                prolongation.setFinProlonge(rs.getDate("finProlonge").toLocalDate().atStartOfDay());
                prolongation.setPrixProlonge(rs.getInt("prixProlonge"));
                prolongations.add(prolongation);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return prolongations;
    }



    public static void deleteLocation(int idContrat) {
        String query = "UPDATE contrat SET supprimerCtr = ? WHERE idContrat = ? ";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1,1);
            ps.setInt(2, idContrat);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addProlongation(Prolongation prolongation) {
        String query = """
            INSERT INTO prolongation (idContrat, finProlonge, prixProlonge) 
            VALUES (?, ?, ?)
        """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, prolongation.getIdContrat());
            ps.setDate(2, java.sql.Date.valueOf(prolongation.getFinProlonge().toLocalDate()));
            ps.setDouble(3, prolongation.getPrixProlonge());

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Prolongation ajoutée avec succès.");
            } else {
                System.out.println("Échec de l'ajout de la prolongation.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erreur lors de l'ajout de la prolongation.");
        }
    }

    public static ChronoLocalDate getLastDate(int contratId) {
        ChronoLocalDate lastDate = null;

        String query = """
        SELECT 
            COALESCE(
                (SELECT MAX(finProlonge) 
                 FROM prolongation 
                 WHERE idContrat = ?),
                (SELECT finContrat 
                 FROM contrat 
                 WHERE idContrat = ?)
            ) AS lastDate
    """;

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, contratId);
            stmt.setInt(2, contratId);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                java.sql.Date sqlDate = rs.getDate("lastDate");
                if (sqlDate != null) {
                    lastDate = sqlDate.toLocalDate(); // Convertir java.sql.Date en LocalDate
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lastDate;
    }
}
