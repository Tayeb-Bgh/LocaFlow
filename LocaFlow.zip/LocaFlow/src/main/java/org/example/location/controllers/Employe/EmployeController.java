package org.example.location.controllers.Employe;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.location.controllers.Switch;
import org.example.location.dbUtils.EmployeDao;
import org.example.location.models.Employe;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class EmployeController {

    @FXML
    TableColumn<Employe, Void> actionColumn;

    @FXML
    private TableView<Employe> employeTable;

    @FXML
    private TableColumn<Employe, Integer> idColumn;
    @FXML
    private TableColumn<Employe, String> nomColumn;
    @FXML
    private TableColumn<Employe, String> prenomColumn;
    @FXML
    private TableColumn<Employe, Integer> telColumn;
    @FXML
    private TableColumn<Employe, String> adressColumn;
    @FXML
    private TableColumn<Employe, Boolean> permissionColumn;

    @FXML
    private TextField searchField;

    @FXML
    private ComboBox<String> filterComboBox;

    @FXML
    private VBox totalEmployeBox;

    @FXML
    private VBox employeWithPermissionBox;

    @FXML
    private VBox employeWithoutPermissionBox;

    @FXML
    private Label totalEmployeLabel;

    @FXML
    private Label employeWithPermissionLabel;

    @FXML
    private Label employeWithoutPermissionLabel;




    private ObservableList<Employe> employeList;

    @FXML
    public void initialize() {
        filterComboBox.setItems(FXCollections.observableArrayList("Nom", "Prénom", "Téléphone", "Adresse"));
        filterComboBox.getSelectionModel().selectFirst(); // Sélection par défaut


        // Écouter les modifications dans le champ de recherche
        searchField.textProperty().addListener((observable, oldValue, newValue) -> handleSearch());

        configureTableColumns();
        setupActionColumn();
        loadData();
    }

    private void configureTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idEmp"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nomEmp"));
        prenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenomEmp"));
        telColumn.setCellValueFactory(new PropertyValueFactory<>("telEmp"));
        adressColumn.setCellValueFactory(new PropertyValueFactory<>("adressEmp"));
        permissionColumn.setCellValueFactory(new PropertyValueFactory<>("permissionEmp"));
    }
    private void setupActionColumn() {
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final FontAwesomeIconView editIcon = new FontAwesomeIconView(FontAwesomeIcon.EDIT);
            private final FontAwesomeIconView deleteIcon = new FontAwesomeIconView(FontAwesomeIcon.TRASH);
            private final FontAwesomeIconView viewIcon = new FontAwesomeIconView(FontAwesomeIcon.EYE);

            {
                editIcon.setStyleClass("action-icon");
                deleteIcon.setStyleClass("action-icon");
                viewIcon.setStyleClass("action-icon");

                editIcon.setOnMouseClicked(event -> {
                    Employe selectedEmploye = getTableView().getItems().get(getIndex());
                    handleEditAction(EmployeDao.getEmployeDetails(selectedEmploye.getIdEmp()));
                });

                deleteIcon.setOnMouseClicked(event -> {
                    Employe selectedEmploye = getTableView().getItems().get(getIndex());
                    handleDeleteAction(selectedEmploye);
                });

                viewIcon.setOnMouseClicked(event -> {
                    try {
                        Employe selectedEmploye = getTableView().getItems().get(getIndex());
                        handleViewDetails(selectedEmploye);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });

                editIcon.setSize("1.8em");
                deleteIcon.setSize("1.8em");
                viewIcon.setSize("1.8em");
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox actions = new HBox(10, editIcon, deleteIcon, viewIcon);
                    actions.setAlignment(Pos.CENTER);
                    setGraphic(actions);
                }
            }
        });
    }

    private void handleEditAction(Employe employe) {
        try {
            // Charger le FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Employe/employe-add-view.fxml"));
            Scene modalScene = new Scene(loader.load(), 800, 790);

            // Obtenir le contrôleur
            EmployeAddController controller = loader.getController();
            controller.setStage((Stage) employeTable.getScene().getWindow());
            controller.setEditMode(employe); // Passer l'employé à modifier

            // Créer une fenêtre modale
            Stage modalStage = new Stage();
            modalStage.initModality(Modality.APPLICATION_MODAL);
            modalStage.initStyle(StageStyle.UNDECORATED);
            modalStage.setScene(modalScene);

            // Ajouter un effet de flou et un overlay
            Scene mainScene = employeTable.getScene();
            HBox root = (HBox) mainScene.getRoot();
            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);
            GaussianBlur blur = new GaussianBlur(10);
            root.getChildren().add(overlay);
            root.setEffect(blur);

            modalStage.setOnHidden(e -> {
                root.getChildren().remove(overlay);
                root.setEffect(null);
                loadData(); // Recharger les données après la modification
            });

            modalStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleDeleteAction(Employe employe) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText(null);
        alert.setContentText("Etes-vous sur de vouloir supprimer cet employé ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            EmployeDao.deleteEmploye(employe.getIdEmp());

            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Employé supprimé avec succès.");
            alert.showAndWait();
        }

        loadData();
    }

    @FXML
    public void handleViewDetails(Employe event) throws IOException {

        // Sélectionner l'employé dans la table
        Employe selectedEmploye = employeTable.getSelectionModel().getSelectedItem();
        if (selectedEmploye == null) return;

        // Récupérer les détails de l'employé
        Employe detailedEmploye = EmployeDao.getEmployeDetails(selectedEmploye.getIdEmp());

        // Charger le fichier FXML correspondant
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Employe/employe-details-view.fxml"));
        Scene modalScene = new Scene(loader.load(), 900, 610);

        // Configurer le contrôleur
        EmployeDetailsController controller = loader.getController();
        controller.setEmployeDetails(detailedEmploye);

        // Créer et configurer la fenêtre modale
        Stage modalStage = new Stage();
        modalStage.initModality(Modality.APPLICATION_MODAL);
        modalStage.initStyle(StageStyle.UNDECORATED);
        modalStage.setScene(modalScene);

        // Ajouter un flou et un overlay à la fenêtre principale
        Scene mainScene = employeTable.getScene();
        HBox root = (HBox) mainScene.getRoot();

        Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
        overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
        overlay.setManaged(false);
        overlay.setMouseTransparent(true);

        GaussianBlur blur = new GaussianBlur(10);
        root.getChildren().add(overlay);
        root.setEffect(blur);

        // Restaurer l'état normal lors de la fermeture
        modalStage.setOnHidden(e -> {
            root.getChildren().remove(overlay);
            root.setEffect(null);
        });

        // Afficher la fenêtre modale
        modalStage.showAndWait();
    }

    private void loadData() {
        try {
            List<Employe> employes = EmployeDao.fetchAllEmployees();
            employeList = FXCollections.observableArrayList(employes);
            employeTable.setItems(employeList);

            updateStatistics();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Erreur lors du chargement des employés.");
            alert.showAndWait();
        }
    }

    private void updateStatistics() {
        int total = employeList.size();
        long withPermission = employeList.stream().filter(e -> e.getPermissionEmp()).count();
        long withoutPermission = total - withPermission;

        totalEmployeLabel.setText(String.valueOf(total));
        employeWithPermissionLabel.setText(String.valueOf(withPermission));
        employeWithoutPermissionLabel.setText(String.valueOf(withoutPermission));
    }

    @FXML
    private void handleAddEmploye() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Employe/employe-add-view.fxml"));
            VBox page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Ajouter un employé");
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.initStyle(StageStyle.UNDECORATED);

            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            EmployeAddController controller = loader.getController();
            controller.setStage(dialogStage);

            Scene mainScene = employeTable.getScene();
            HBox root = (HBox) mainScene.getRoot();

            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);

            GaussianBlur blur = new GaussianBlur(10);
            root.getChildren().add(overlay);
            root.setEffect(blur);

            dialogStage.setOnHidden(e -> {
                root.getChildren().remove(overlay);
                root.setEffect(null);
                if (controller.isSaveClicked()) {
                    Employe newEmploye = controller.getNewEmploye();
                    EmployeDao.addEmploye(newEmploye);
                    loadData();
                }
            });

            dialogStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Erreur lors de l'ouverture du formulaire d'ajout d'employé.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleVehicules(MouseEvent event) {
        Switch.changeScene(event, "view/Voiture/voiture-view.fxml");
    }

    @FXML
    private void handleLocations(MouseEvent event) {
        Switch.changeScene(event, "view/Location/location-view.fxml");
    }

    @FXML
    private void handlePaiements(MouseEvent event) {
        Switch.changeScene(event, "view/Paiement/paiement-view.fxml");
    }

    @FXML
    private void handleDashboard(MouseEvent event) {
        Switch.changeScene(event, "view/Dashboard/dashboard-view.fxml");
    }


    @FXML
    private void handleClient(MouseEvent event) {
        Switch.changeScene(event, "view/Client/client-view.fxml");
    }

    @FXML
    public void handleEmploye(MouseEvent event) {
        Switch.changeScene(event, "view/Employe/employe-view.fxml");
    }

    public void handleFilterChange(ActionEvent event) {
    }

    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().toLowerCase();
        String filterBy = filterComboBox.getSelectionModel().getSelectedItem();

        if (searchTerm.isEmpty()) {
            loadData(); // Si le champ de recherche est vide, recharger toutes les données
            return;
        }

        ObservableList<Employe> filteredEmployes = employeList.filtered(employe -> {
            switch (filterBy) {
                case "Nom":
                    return employe.getNomEmp().toLowerCase().contains(searchTerm);
                case "Prénom":
                    return employe.getPrenomEmp().toLowerCase().contains(searchTerm);
                case "Téléphone":
                    return String.valueOf(employe.getTelEmp()).contains(searchTerm);
                case "Adresse":
                    return employe.getAdressEmp().toLowerCase().contains(searchTerm);
                default:
                    return false;
            }
        });

        employeTable.setItems(filteredEmployes);
    }
    @FXML
    private void handleFilterChange() {
        handleSearch(); // Réappliquer le filtre lorsque l'utilisateur change de critère
    }

    @FXML
    private void filterTotalEmployes() {
        // Filtre qui affiche tous les employés
        employeTable.setItems(employeList);
        reloadActionColumn();
    }

    @FXML
    private void filterEmployesWithPermission() {
        // Filtre les employés avec permission (permissionEmp = true)
        ObservableList<Employe> filteredEmployes = employeList.filtered(employe -> employe.getPermissionEmp());
        employeTable.setItems(filteredEmployes);
        reloadActionColumn();
    }

    @FXML
    private void filterEmployesWithoutPermission() {
        // Filtre les employés sans permission (permissionEmp = false)
        ObservableList<Employe> filteredEmployes = employeList.filtered(employe -> !employe.getPermissionEmp());
        employeTable.setItems(filteredEmployes);
        reloadActionColumn();
    }
    private void reloadActionColumn() {
        // On rend la colonne d'action invisible puis visible, ce qui force son rafraîchissement
        employeTable.getColumns().get(employeTable.getColumns().size() - 1).setVisible(false);
        employeTable.getColumns().get(employeTable.getColumns().size() - 1).setVisible(true);
    }


}
