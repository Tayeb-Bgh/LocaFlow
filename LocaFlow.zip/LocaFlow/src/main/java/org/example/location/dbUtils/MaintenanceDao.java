package org.example.location.dbUtils;

import org.example.location.models.Maintenance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceDao {


    public static List<Maintenance> fetchMaintenancesByVehicleId(int vehicleId) {
        List<Maintenance> maintenances = new ArrayList<>();

        String query = """
                SELECT idMaintenance, debMaintenance, finMaintenance, prixMaintenance
                FROM maintenance
                WHERE idVeh = ?
                """;

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, vehicleId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Maintenance maintenance = new Maintenance(
                            resultSet.getInt("idMaintenance"),
                            resultSet.getDate("debMaintenance").toLocalDate(),
                            resultSet.getDate("finMaintenance") != null ? resultSet.getDate("finMaintenance").toLocalDate() : null,
                            resultSet.getInt("prixMaintenance")
                    );
                    maintenances.add(maintenance);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Gestion des erreurs
        }

        return maintenances;
    }
}
