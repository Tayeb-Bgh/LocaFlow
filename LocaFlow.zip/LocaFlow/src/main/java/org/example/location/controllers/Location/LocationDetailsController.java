package org.example.location.controllers.Location;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.location.dbUtils.LocationDao;
import org.example.location.models.Contrat;
import org.example.location.models.Prolongation;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class LocationDetailsController {

    @FXML private Label creeParContratLabel;
    @FXML private Label statutLabel;
    @FXML private Label idContratLabel;
    @FXML private Label nomClientLabel;
    @FXML private Label nomVehiculeLabel;
    @FXML private Label debContratLabel;
    @FXML private Label finContratLabel;
    @FXML private Label prixContratLabel;

    @FXML private TableView<Prolongation> prolongationsTable;
    @FXML private TableColumn<Prolongation, String> dateColumn;
    @FXML private TableColumn<Prolongation, String> montantColumn;

    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private Contrat currentContrat = new Contrat();

    public void setLocationDetails(Contrat contrat) {
        currentContrat = contrat;
        idContratLabel.setText(String.valueOf(contrat.getIdContrat()));
        nomClientLabel.setText(contrat.getClient().getNomClt());
        nomVehiculeLabel.setText(contrat.getVehicule().getModeleVeh());
        debContratLabel.setText(contrat.getDebContrat().format(dateFormatter));
        finContratLabel.setText(contrat.getFinContrat().format(dateFormatter));
        prixContratLabel.setText(String.format("%.2f DA", contrat.getPrixContrat()));
        creeParContratLabel.setText(contrat.getEmploye().getNomEmp()+" "+contrat.getEmploye().getPrenomEmp());
        statutLabel.setText(contrat.getStatutContrat() ? "Terminer" : "En cours");

        loadProlongations(contrat);
    }

    private void loadProlongations(Contrat contrat) {
        ObservableList<Prolongation> prolongationList = FXCollections.observableArrayList(LocationDao.getProlongationsByContratId(contrat.getIdContrat()));

        dateColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getFinProlonge().format(dateFormatter))
        );

        montantColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(String.format("%.2f DA", (double) cellData.getValue().getPrixProlonge()))
        );


        prolongationsTable.setItems(prolongationList);
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) idContratLabel.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleAddProlongation() {
        try {
            if (currentContrat.getStatutContrat() == false) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Location/prolongation-add-view.fxml"));
                Scene modalScene = new Scene(loader.load(), 400, 300);


                ProlongationAddController controller = loader.getController();
                controller.setContratId(Integer.parseInt(idContratLabel.getText()));

                // Configurer la fenêtre modale
                Stage modalStage = new Stage();
                modalStage.initModality(Modality.APPLICATION_MODAL);
                modalStage.setScene(modalScene);

                modalStage.showAndWait();

                // Rafraîchir le tableau des prolongations après l'ajout
                Contrat contrat = LocationDao.getContratById(Integer.parseInt(idContratLabel.getText()));
                setLocationDetails(contrat);
            }
            else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText("Une erreur s'est produite");
                alert.setContentText("Impossible de prolonger un contrat deja fini.");

                alert.showAndWait();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleValidateLocation() {
        if (currentContrat.getStatutContrat() == false) {
            int contratId = Integer.parseInt(idContratLabel.getText());
            int nouveauKilometrage = -1;

            // Boîte de dialogue pour saisir le kilométrage
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Saisie du Kilométrage");
            dialog.setHeaderText("Saisir le nouveau kilométrage du véhicule");
            dialog.setContentText("Nouveau kilométrage:");

            // Récupérer la saisie de l'utilisateur
            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                try {
                    nouveauKilometrage = Integer.parseInt(result.get());
                    if (nouveauKilometrage < 0) {
                        throw new NumberFormatException("Kilométrage négatif non autorisé.");
                    }
                    System.out.println(contratId);
                    System.out.println(nouveauKilometrage);
                    // Mise à jour du kilométrage dans la base de données
                    LocationDao.updateVehicleKilometrage(contratId, nouveauKilometrage);

                    // Valider la location
                    LocationDao.validateLocation(contratId);

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Succès");
                    alert.setHeaderText(null);
                    alert.setContentText("Contrat validé avec succès.");
                    alert.showAndWait();

                } catch (NumberFormatException e) {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Erreur de saisie");
                    errorAlert.setHeaderText("Saisie invalide");
                    errorAlert.setContentText("Veuillez saisir un kilométrage valide (nombre entier positif).");
                    errorAlert.showAndWait();
                }
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Une erreur s'est produite");
            alert.setContentText("Impossible de valider un contrat déjà terminé.");
            alert.showAndWait();
        }
    }

}
