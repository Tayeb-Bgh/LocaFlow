package org.example.location.models;



import java.time.LocalDate;
import java.util.List;

public class Client {
    private int idClt;
    private String nomClt;
    private String prenomClt;
    private LocalDate dateNaiss;
    private int numPermis;
    private String adressClt;
    private int telClt;
    private Boolean supprimerClt;
    private LocalDate dateExprPermis;
    private LocalDate dateDelivrPermis;
    private List<Contrat> contrats;

    public Client(String nomClt, String prenomClt) {
        this.nomClt =nomClt;
        this.prenomClt =prenomClt;

    }

    public Client() {

    }

    public Boolean getLastContratStatut() {
        if (contrats == null || contrats.isEmpty()) {
            return null;
        }
        return contrats.get(contrats.size() - 1).getStatutContrat();
    }


    public void setNomClt(String nomClt) {
        this.nomClt = nomClt;
    }

    public void setPrenomClt(String prenomClt) {
        this.prenomClt = prenomClt;
    }

    public void setDateNaiss(LocalDate dateNaiss) {
        this.dateNaiss = dateNaiss;
    }

    public void setNumPermis(int numPermis) {
        this.numPermis = numPermis;
    }

    public void setAdressClt(String adressClt) {
        this.adressClt = adressClt;
    }

    public void setTelClt(int telClt) {
        this.telClt = telClt;
    }

    public void setSupprimerClt(Boolean supprimerClt) {
        this.supprimerClt = supprimerClt;
    }

    public void setDateExprPermis(LocalDate dateExprPermis) {
        this.dateExprPermis = dateExprPermis;
    }

    public void setDateDelivrPermis(LocalDate dateDelivrPermis) {
        this.dateDelivrPermis = dateDelivrPermis;
    }

    public void setContrats(List<Contrat> contrats) {
        this.contrats = contrats;
    }

    public String getNomClt() {
        return nomClt;
    }

    public String getPrenomClt() {
        return prenomClt;
    }

    public LocalDate getDateNaiss() {
        return dateNaiss;
    }

    public int getNumPermis() {
        return numPermis;
    }

    public String getAdressClt() {
        return adressClt;
    }

    public int getTelClt() {
        return telClt;
    }

    public Boolean getSupprimerClt() {
        return supprimerClt;
    }

    public LocalDate getDateExprPermis() {
        return dateExprPermis;
    }

    public LocalDate getDateDelivrPermis() {
        return dateDelivrPermis;
    }

    public List<Contrat> getContrats() {
        return contrats;
    }

    public int getIdClt() {
        return idClt;
    }

    public void setIdClt(int idClt) {
        this.idClt = idClt;
    }
}