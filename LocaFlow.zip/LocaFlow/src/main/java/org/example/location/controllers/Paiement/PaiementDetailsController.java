package org.example.location.controllers.Paiement;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.location.models.Contrat;
import org.example.location.models.Paiement;
import org.example.location.dbUtils.PaiementDao;

import java.net.URL;
import java.util.ResourceBundle;

public class PaiementDetailsController implements Initializable {


    @FXML
    private Label idContratLabel;

    @FXML
    private Label nomClientLabel;

    @FXML
    private Label nomVehiculeLabel;

    @FXML
    private Label dateDebutLabel;

    @FXML
    private Label dateFinLabel;

    @FXML
    private Label montantTotalLabel;

    @FXML
    private Label montantPayeLabel;

    @FXML
    private Label montantRestantLabel;

    @FXML
    private TableView<Paiement> paiementTable   ;

    @FXML
    private TableColumn<Paiement, Integer> idPaiementColumn;

    @FXML
    private TableColumn<Paiement, String> datePaiementColumn;

    @FXML
    private TableColumn<Paiement, Double> montantPayeColumn;

    @FXML
    private TableColumn<Paiement, String> methodPaiementColumn;

    private Contrat contrat;

    private Stage stage;

    /**
     * Cette méthode est appelée automatiquement lorsque le FXML est chargé.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
    }

    /**
     * Configure les colonnes de la TableView.
     */

    private void setupTableColumns() {
        idPaiementColumn.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getIdPaiement()));

        datePaiementColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(
                        cellData.getValue().getDatePaiement() != null ?
                                cellData.getValue().getDatePaiement().toString() : "N/A"
                ));
        montantPayeColumn.setCellValueFactory(new PropertyValueFactory<>("montantPaiement"));
    }



    public void setContratDetails(Contrat contrat) {
        this.contrat = contrat;

        // Remplir les champs de texte du contrat
        idContratLabel.setText(String.valueOf(contrat.getIdContrat()));
        nomClientLabel.setText(contrat.getClient().getNomClt());
        nomVehiculeLabel.setText(contrat.getVehicule().getModeleVeh());
        dateDebutLabel.setText(contrat.getDebContrat().toString());
        dateFinLabel.setText(contrat.getFinContrat().toString());
        montantTotalLabel.setText(String.format("%.2f DA", contrat.getPrixContrat()));

        // Calculer le montant payé et le montant restant
        double montantPaye = contrat.getPaiements().stream().mapToDouble(Paiement::getMontantPaiement).sum();
        montantPayeLabel.setText(String.format("%.2f DA", montantPaye));
        double montantRestant = contrat.getPrixContrat() - montantPaye;
        montantRestantLabel.setText(String.format("%.2f DA", montantRestant));


        loadPaiementHistory();
    }


    private void loadPaiementHistory() {
        paiementTable.getItems().clear();
        paiementTable.getItems().addAll(PaiementDao.getPaiementsByContratId(contrat.getIdContrat()));
    }


    public void setStage(Stage stage) {
        this.stage = stage;
    }



    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
