package org.example.location.controllers.Agence;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.dbUtils.AgenceDao;
import org.example.location.models.Agence;

public class AgenceDetailsController {

    @FXML private TextField nomAgenceField;
    @FXML private TextField telAgenceField;
    @FXML private TextField adressAgenceField;
    @FXML private TextField faxAgenceField;
    @FXML private TextField registreAgenceField;
    @FXML private TextField codeFiscalAgenceField;
    @FXML private TextField articleImpositionAgenceField;
    @FXML private TextField reglementAgenceField;
    @FXML private TextField remarqueAgenceField;

    private Agence agence=new Agence();

    public void initialize() {
        loadAgenceDetails();
    }

    private void loadAgenceDetails() {
        // Charger les données depuis la base de données
        agence = AgenceDao.getAgence();
        if (agence != null) {
            nomAgenceField.setText(agence.getNomAgence());
            telAgenceField.setText(agence.getTelAgence());
            adressAgenceField.setText(agence.getAdressAgence());
            faxAgenceField.setText(agence.getFaxAgence());
            registreAgenceField.setText(agence.getRegistreAgence());
            codeFiscalAgenceField.setText(agence.getCodeFiscalAgence());
            articleImpositionAgenceField.setText(agence.getArticleImpositionAgence());
            reglementAgenceField.setText(agence.getReglementAgence());
            remarqueAgenceField.setText(agence.getRemarqueAgence());
        }
    }

    @FXML
    private void handleSave() {
        agence=new Agence();
        // Mettre à jour les données dans l'objet Agence
        agence.setNomAgence(nomAgenceField.getText());
        agence.setTelAgence(telAgenceField.getText());
        agence.setAdressAgence(adressAgenceField.getText());
        agence.setFaxAgence(faxAgenceField.getText());
        agence.setRegistreAgence(registreAgenceField.getText());
        agence.setCodeFiscalAgence(codeFiscalAgenceField.getText());
        agence.setArticleImpositionAgence(articleImpositionAgenceField.getText());
        agence.setReglementAgence(reglementAgenceField.getText());
        agence.setRemarqueAgence(remarqueAgenceField.getText());

        // Sauvegarder dans la base de données
        AgenceDao.updateAgence(agence);

        // Fermer la fenêtre
        handleClose();
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) nomAgenceField.getScene().getWindow();
        stage.close();
    }
}
