package org.example.location.models;

import java.time.LocalDate;
import java.util.List;

public class Employe {
    private int idEmp;
    private String nomEmp;
    private String prenomEmp;
    private int telEmp;
    private String adressEmp;
    private int ccpEmp;
    private char sexeEmp;
    private LocalDate dateNaissEmp;
    private Boolean permissionEmp;
    private String usernameEmp;

    public String getUsernameEmp() {
        return usernameEmp;
    }

    public void setUsernameEmp(String usernameEmp) {
        this.usernameEmp = usernameEmp;
    }

    private String mdpEmp;
    private Boolean supprimerEmp;

    private List<Contrat> contrats;

    public int getIdEmp() {
        return idEmp;
    }

    public void setIdEmp(int idEmp) {
        this.idEmp = idEmp;
    }

    public String getNomEmp() {
        return nomEmp;
    }

    public void setNomEmp(String nomEmp) {
        this.nomEmp = nomEmp;
    }

    public String getPrenomEmp() {
        return prenomEmp;
    }

    public void setPrenomEmp(String prenomEmp) {
        this.prenomEmp = prenomEmp;
    }

    public int getTelEmp() {
        return telEmp;
    }

    public void setTelEmp(int telEmp) {
        this.telEmp = telEmp;
    }

    public String getAdressEmp() {
        return adressEmp;
    }

    public void setAdressEmp(String adressEmp) {
        this.adressEmp = adressEmp;
    }

    public int getCcpEmp() {
        return ccpEmp;
    }

    public void setCcpEmp(int ccpEmp) {
        this.ccpEmp = ccpEmp;
    }

    public char getSexeEmp() {
        return sexeEmp;
    }

    public void setSexeEmp(char sexeEmp) {
        this.sexeEmp = sexeEmp;
    }

    public LocalDate getDateNaissEmp() {
        return dateNaissEmp;
    }

    public void setDateNaissEmp(LocalDate dateNaissEmp) {
        this.dateNaissEmp = dateNaissEmp;
    }

    public Boolean getPermissionEmp() {
        return permissionEmp;
    }

    public void setPermissionEmp(Boolean permissionEmp) {
        this.permissionEmp = permissionEmp;
    }

    public String getMdpEmp() {
        return mdpEmp;
    }

    public void setMdpEmp(String mdpEmp) {
        this.mdpEmp = mdpEmp;
    }

    public Boolean getSupprimerEmp() {
        return supprimerEmp;
    }

    public void setSupprimerEmp(Boolean supprimerEmp) {
        this.supprimerEmp = supprimerEmp;
    }

    public List<Contrat> getContrats() {
        return contrats;
    }

    public void setContrats(List<Contrat> contrats) {
        this.contrats = contrats;
    }
}
