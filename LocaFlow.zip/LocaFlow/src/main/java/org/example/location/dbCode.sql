-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 18 déc. 2024 à 08:32
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `locaflow`
--

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

CREATE TABLE `agence` (
  `idAgence` int NOT NULL,
  `nomAgence` varchar(255) DEFAULT NULL,
  `telAgence` varchar(15) DEFAULT NULL,
  `adressAgence` varchar(255) DEFAULT NULL,
  `faxAgence` varchar(15) DEFAULT NULL,
  `registreAgence` varchar(255) DEFAULT NULL,
  `codeFiscalAgence` varchar(255) DEFAULT NULL,
  `articleImpositionAgence` varchar(255) DEFAULT NULL,
  `reglementAgence` text,
  `remarqueAgence` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `agence`
--

INSERT INTO `agence` (`idAgence`, `nomAgence`, `telAgence`, `adressAgence`, `faxAgence`, `registreAgence`, `codeFiscalAgence`, `articleImpositionAgence`, `reglementAgence`, `remarqueAgence`) VALUES
(1, 'Agence XYZ', '0123456789', '123 Rue Exemple', '0123456790', 'RC-123456', 'CF-654321', 'Article-123', 'Règlement Exemple', 'Aucune remarque');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `idClt` int NOT NULL,
  `nomClt` varchar(255) DEFAULT NULL,
  `prenomClt` varchar(255) DEFAULT NULL,
  `dateNaiss` date DEFAULT NULL,
  `numPermis` int DEFAULT NULL,
  `adressClt` varchar(255) DEFAULT NULL,
  `telClt` varchar(15) DEFAULT NULL,
  `dateExprPermis` date DEFAULT NULL,
  `supprimerClt` tinyint(1) DEFAULT NULL,
  `dateDelivrPermis` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `client`
--


-- --------------------------------------------------------

--
-- Structure de la table `contrat`
--

CREATE TABLE `contrat` (
  `idContrat` int NOT NULL,
  `debContrat` datetime DEFAULT NULL,
  `finContrat` datetime DEFAULT NULL,
  `prixContrat` int DEFAULT NULL,
  `cautionContrat` int DEFAULT NULL,
  `statutContrat` tinyint(1) DEFAULT NULL,
  `nbRetard` time DEFAULT NULL,
  `idClt` int DEFAULT NULL,
  `idVeh` int DEFAULT NULL,
  `idEmp` int NOT NULL,
  `supprimerCtr` int DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `contrat`
--


-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

CREATE TABLE `employe` (
  `idEmp` int NOT NULL,
  `nomEmp` varchar(255) NOT NULL,
  `prenomEmp` varchar(255) NOT NULL,
  `telEmp` varchar(20) DEFAULT NULL,
  `adressEmp` varchar(199) DEFAULT NULL,
  `ccpEmp` int DEFAULT NULL,
  `sexeEmp` char(1) DEFAULT NULL,
  `dateNaissEmp` date DEFAULT NULL,
  `permissionEmp` tinyint(1) DEFAULT '0',
  `mdpEmp` varchar(255) NOT NULL,
  `supprimerEmp` tinyint(1) DEFAULT '0',
  `usernameEmp` varchar(66) DEFAULT NULL
) ;

--
-- Déchargement des données de la table `employe`
--


-- --------------------------------------------------------

--
-- Structure de la table `maintenance`
--

CREATE TABLE `maintenance` (
  `idMaintenance` int NOT NULL,
  `idVeh` int DEFAULT NULL,
  `debMaintenance` date DEFAULT NULL,
  `finMaintenance` date DEFAULT NULL,
  `prixMaintenance` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `maintenance`
--


-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE `paiement` (
  `idPaiement` int NOT NULL,
  `idContrat` int DEFAULT NULL,
  `datePaiement` datetime DEFAULT NULL,
  `montantPaiement` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `paiement`
--


-- --------------------------------------------------------

--
-- Structure de la table `prolongation`
--

CREATE TABLE `prolongation` (
  `idProlonge` int NOT NULL,
  `idContrat` int DEFAULT NULL,
  `finProlonge` datetime DEFAULT NULL,
  `prixProlonge` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `prolongation`
--


-- --------------------------------------------------------

--
-- Structure de la table `suivie`
--

CREATE TABLE `suivie` (
  `idOption` int NOT NULL,
  `idVeh` int DEFAULT NULL,
  `assuranceExp` date DEFAULT NULL,
  `controleTechExp` date DEFAULT NULL,
  `vidangeExp` int DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `suivie`
--



-- --------------------------------------------------------

--
-- Structure de la table `vehicule`
--

CREATE TABLE `vehicule` (
  `idVeh` int NOT NULL,
  `matriculeVeh` varchar(50) DEFAULT NULL,
  `modeleVeh` varchar(255) DEFAULT NULL,
  `marqueVeh` varchar(255) DEFAULT NULL,
  `numChassisVeh` varchar(255) DEFAULT NULL,
  `couleurVeh` varchar(50) DEFAULT NULL,
  `carteGriseVeh` varchar(255) DEFAULT NULL,
  `energieVeh` varchar(50) DEFAULT NULL,
  `supprimerVeh` tinyint(1) DEFAULT NULL,
  `kilometrage` int DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `vehicule`
--


--
-- Index pour les tables déchargées
--

--
-- Index pour la table `agence`
--
ALTER TABLE `agence`
  ADD PRIMARY KEY (`idAgence`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`idClt`);

--
-- Index pour la table `contrat`
--
ALTER TABLE `contrat`
  ADD PRIMARY KEY (`idContrat`),
  ADD KEY `idClt` (`idClt`),
  ADD KEY `idVeh` (`idVeh`),
  ADD KEY `fk_idEmp` (`idEmp`);

--
-- Index pour la table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`idEmp`),
  ADD UNIQUE KEY `usernameEmp` (`usernameEmp`);

--
-- Index pour la table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`idMaintenance`),
  ADD KEY `idVeh` (`idVeh`);

--
-- Index pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD PRIMARY KEY (`idPaiement`),
  ADD KEY `idContrat` (`idContrat`);

--
-- Index pour la table `prolongation`
--
ALTER TABLE `prolongation`
  ADD PRIMARY KEY (`idProlonge`),
  ADD KEY `idContrat` (`idContrat`);

--
-- Index pour la table `suivie`
--
ALTER TABLE `suivie`
  ADD PRIMARY KEY (`idOption`),
  ADD KEY `idVeh` (`idVeh`);

--
-- Index pour la table `vehicule`
--
ALTER TABLE `vehicule`
  ADD PRIMARY KEY (`idVeh`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `agence`
--
ALTER TABLE `agence`
  MODIFY `idAgence` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `idClt` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `contrat`
--
ALTER TABLE `contrat`
  MODIFY `idContrat` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `employe`
--
ALTER TABLE `employe`
  MODIFY `idEmp` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `maintenance`
--
ALTER TABLE `maintenance`
  MODIFY `idMaintenance` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `paiement`
--
ALTER TABLE `paiement`
  MODIFY `idPaiement` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `prolongation`
--
ALTER TABLE `prolongation`
  MODIFY `idProlonge` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `suivie`
--
ALTER TABLE `suivie`
  MODIFY `idOption` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT pour la table `vehicule`
--
ALTER TABLE `vehicule`
  MODIFY `idVeh` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
