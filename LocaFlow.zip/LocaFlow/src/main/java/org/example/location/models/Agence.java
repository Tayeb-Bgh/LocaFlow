package org.example.location.models;

public class Agence {
    private int idAgence;
    private String nomAgence;
    private String telAgence;
    private String adressAgence;
    private String faxAgence;
    private String registreAgence;
    private String codeFiscalAgence;
    private String articleImpositionAgence;
    private String reglementAgence;
    private String remarqueAgence;

    // **Constructeur complet**
    public Agence(int idAgence, String nomAgence, String telAgence, String adressAgence, String faxAgence,
                  String registreAgence, String codeFiscalAgence, String articleImpositionAgence,
                  String reglementAgence, String remarqueAgence) {
        this.idAgence = idAgence;
        this.nomAgence = nomAgence;
        this.telAgence = telAgence;
        this.adressAgence = adressAgence;
        this.faxAgence = faxAgence;
        this.registreAgence = registreAgence;
        this.codeFiscalAgence = codeFiscalAgence;
        this.articleImpositionAgence = articleImpositionAgence;
        this.reglementAgence = reglementAgence;
        this.remarqueAgence = remarqueAgence;
    }

    public Agence() {

    }

    // **Getters et Setters**
    public int getIdAgence() {
        return idAgence;
    }

    public void setIdAgence(int idAgence) {
        this.idAgence = idAgence;
    }

    public String getNomAgence() {
        return nomAgence;
    }

    public void setNomAgence(String nomAgence) {
        this.nomAgence = nomAgence;
    }

    public String getTelAgence() {
        return telAgence;
    }

    public void setTelAgence(String telAgence) {
        this.telAgence = telAgence;
    }

    public String getAdressAgence() {
        return adressAgence;
    }

    public void setAdressAgence(String adressAgence) {
        this.adressAgence = adressAgence;
    }

    public String getFaxAgence() {
        return faxAgence;
    }

    public void setFaxAgence(String faxAgence) {
        this.faxAgence = faxAgence;
    }

    public String getRegistreAgence() {
        return registreAgence;
    }

    public void setRegistreAgence(String registreAgence) {
        this.registreAgence = registreAgence;
    }

    public String getCodeFiscalAgence() {
        return codeFiscalAgence;
    }

    public void setCodeFiscalAgence(String codeFiscalAgence) {
        this.codeFiscalAgence = codeFiscalAgence;
    }

    public String getArticleImpositionAgence() {
        return articleImpositionAgence;
    }

    public void setArticleImpositionAgence(String articleImpositionAgence) {
        this.articleImpositionAgence = articleImpositionAgence;
    }

    public String getReglementAgence() {
        return reglementAgence;
    }

    public void setReglementAgence(String reglementAgence) {
        this.reglementAgence = reglementAgence;
    }

    public String getRemarqueAgence() {
        return remarqueAgence;
    }

    public void setRemarqueAgence(String remarqueAgence) {
        this.remarqueAgence = remarqueAgence;
    }

    // **toString pour débogage (optionnel)**
    @Override
    public String toString() {
        return "Agence{" +
                "idAgence=" + idAgence +
                ", nomAgence='" + nomAgence + '\'' +
                ", telAgence='" + telAgence + '\'' +
                ", adressAgence='" + adressAgence + '\'' +
                ", faxAgence='" + faxAgence + '\'' +
                ", registreAgence='" + registreAgence + '\'' +
                ", codeFiscalAgence='" + codeFiscalAgence + '\'' +
                ", articleImpositionAgence='" + articleImpositionAgence + '\'' +
                ", reglementAgence='" + reglementAgence + '\'' +
                ", remarqueAgence='" + remarqueAgence + '\'' +
                '}';
    }
}
