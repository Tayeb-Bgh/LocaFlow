package org.example.location.controllers.Location;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.location.dbUtils.LocationDao;
import org.example.location.models.Contrat;

import java.time.LocalDate;
import java.util.List;

public class LocationAddController {

    @FXML
    private ComboBox<String> clientComboBox;

    @FXML
    private ComboBox<String> vehicleComboBox;

    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private TextField amountField;

    @FXML
    private TextField cautionField;

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    public void initialize() {
        loadAvailableClients();
        loadAvailableVehicles();
    }

    private void loadAvailableClients() {
        List<String> availableClients = LocationDao.getAvailableClients();
        ObservableList<String> clientList = FXCollections.observableArrayList(availableClients);
        clientComboBox.setItems(clientList);
    }

    private void loadAvailableVehicles() {
        List<String> availableVehicles = LocationDao.getAvailableVehicles();
        ObservableList<String> vehicleList = FXCollections.observableArrayList(availableVehicles);
        vehicleComboBox.setItems(vehicleList);
    }

    @FXML
    public void handleSave() {
        try {
            Contrat newContrat = new Contrat();

            if (!isInputValid()) {
                return;
            }

            // Extract client and vehicle ID from ComboBox (assuming format "ID - Name")
            int clientId = Integer.parseInt(clientComboBox.getValue().split(" - ")[0]);
            int vehicleId = Integer.parseInt(vehicleComboBox.getValue().split(" - ")[0]);

            newContrat.setIdClient(clientId);
            newContrat.setIdVehicule(vehicleId);
            newContrat.setDebContrat(startDatePicker.getValue().atStartOfDay());
            newContrat.setFinContrat(endDatePicker.getValue().atStartOfDay());
            newContrat.setPrixContrat(Double.parseDouble(amountField.getText()));
            newContrat.setCautionContrat(Double.parseDouble(cautionField.getText()));


            LocationDao.addLocation(newContrat);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Le contrat a été ajouté avec succès.");
            alert.showAndWait();
            stage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        StringBuilder errorMessage = new StringBuilder();

        // 1. Vérification des combobox de client et de véhicule
        if (clientComboBox.getValue() == null || clientComboBox.getValue().isEmpty()) {
            errorMessage.append("Veuillez sélectionner un client.\n");
        }
        if (vehicleComboBox.getValue() == null || vehicleComboBox.getValue().isEmpty()) {
            errorMessage.append("Veuillez sélectionner un véhicule.\n");
        }

        // 2. Vérification des dates de début et de fin de contrat
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();

        if (startDate == null) {
            errorMessage.append("Veuillez sélectionner la date de début du contrat.\n");
        } else if (startDate.isBefore(LocalDate.now().minusDays(2))) {
            errorMessage.append("La date de début ne peut pas être dans le passé.\n");
        }

        if (endDate == null) {
            errorMessage.append("Veuillez sélectionner la date de fin du contrat.\n");
        } else if (startDate != null && endDate.isBefore(startDate)) {
            errorMessage.append("La date de fin doit être postérieure à la date de début.\n");
        }

        // 3. Vérification du montant du contrat (doit être un nombre positif)
        String amountText = amountField.getText();
        if (amountText == null || amountText.trim().isEmpty()) {
            errorMessage.append("Le montant est requis.\n");
        } else {
            try {
                double amount = Double.parseDouble(amountText);
                if (amount <= 0) {
                    errorMessage.append("Le montant doit être supérieur à 0.\n");
                }
            } catch (NumberFormatException e) {
                errorMessage.append("Le montant doit être un nombre valide.\n");
            }
        }

        // 4. Vérification de la caution (doit être un nombre positif)
        String cautionText = cautionField.getText();
        if (cautionText == null || cautionText.trim().isEmpty()) {
            errorMessage.append("La caution est requise.\n");
        } else {
            try {
                double caution = Double.parseDouble(cautionText);
                if (caution < 0) {
                    errorMessage.append("La caution ne peut pas être négative.\n");
                }
            } catch (NumberFormatException e) {
                errorMessage.append("La caution doit être un nombre valide.\n");
            }
        }

        // Afficher les erreurs s'il y en a
        if (errorMessage.length() > 0) {
            showError("Champs invalides", errorMessage.toString());
            return false;
        }

        return true;
    }
    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
