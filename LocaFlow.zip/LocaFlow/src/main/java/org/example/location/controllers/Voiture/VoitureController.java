package org.example.location.controllers.Voiture;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.location.HelloApplication;
import org.example.location.controllers.Client.ClientDetailsController;
import org.example.location.controllers.Switch;
import org.example.location.dbUtils.ClientDAO;
import org.example.location.dbUtils.VoitureDao;
import org.example.location.models.Client;
import org.example.location.models.Vehicule;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class VoitureController {


    @FXML
    private TableView<Vehicule> clientsTable;

    @FXML
    private TableColumn<Vehicule, Integer> idColumn;
    @FXML
    private TableColumn<Vehicule, String> marqueColumn;
    @FXML
    private TableColumn<Vehicule, String> modeleColumn;
    @FXML
    private TableColumn<Vehicule, String> dateExpAssuranceColumn;
    @FXML
    private TableColumn<Vehicule, String> dateExpControleColumn;
    @FXML
    private TableColumn<Vehicule, String> energieColumn;
    @FXML
    private TableColumn<Vehicule, Integer> vidangeColumn;
    @FXML
    private TableColumn<Vehicule, String> statutColumn;
    @FXML
    private TableColumn<Vehicule, Void> actionColumn;

    @FXML
    private Label totalVoitureLabel;
    @FXML
    private Label vehiclesInMaintenanceLabel;
    @FXML
    private Label vehiclesInUseLabel;
    @FXML
    private Label availableVehiclesLabel;

    @FXML
    private TextField searchField;
    @FXML
    private ComboBox<String> filterComboBox;

    private ObservableList<Vehicule> vehiculeList;

    @FXML
    public void initialize() {
        filterComboBox.setItems(FXCollections.observableArrayList("Marque", "Modèle", "Énergie"));
        filterComboBox.getSelectionModel().selectFirst(); // Sélectionne la première option par défaut

        loadData();
        setupActionColumn();
    }

    private void loadData() {
        try {
            List<Vehicule> vehicules = VoitureDao.fetchAllVehicles();
            vehiculeList = FXCollections.observableArrayList(vehicules);

            idColumn.setCellValueFactory(new PropertyValueFactory<>("idVeh"));
            marqueColumn.setCellValueFactory(new PropertyValueFactory<>("marqueVeh"));
            modeleColumn.setCellValueFactory(new PropertyValueFactory<>("modeleVeh"));

            dateExpAssuranceColumn.setCellValueFactory(cellData -> {
                if (!cellData.getValue().getSuivies().isEmpty() && cellData.getValue().getSuivies().get(0).getAssuranceExp() != null) {
                    return new SimpleStringProperty(cellData.getValue().getSuivies().get(0).getAssuranceExp().toString());
                }
                return new SimpleStringProperty("");
            });

            dateExpControleColumn.setCellValueFactory(cellData -> {
                if (!cellData.getValue().getSuivies().isEmpty() && cellData.getValue().getSuivies().get(0).getControleTechExp() != null) {
                    return new SimpleStringProperty(cellData.getValue().getSuivies().get(0).getControleTechExp().toString());
                }
                return new SimpleStringProperty("");
            });

            vidangeColumn.setCellValueFactory(cellData -> {
                if (!cellData.getValue().getSuivies().isEmpty()) {
                    Integer vidange = cellData.getValue().getSuivies().get(0).getVidangeExp();
                    return new SimpleIntegerProperty(vidange != null ? vidange : 0).asObject();
                }
                return new SimpleIntegerProperty(0).asObject();
            });

            energieColumn.setCellValueFactory(new PropertyValueFactory<>("energieVeh"));
            statutColumn.setCellValueFactory(new PropertyValueFactory<>("statutVeh"));

            clientsTable.setItems(vehiculeList);
            updateStatistics();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupActionColumn() {
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final FontAwesomeIconView editIcon = new FontAwesomeIconView(FontAwesomeIcon.EDIT);
            private final FontAwesomeIconView deleteIcon = new FontAwesomeIconView(FontAwesomeIcon.TRASH);
            private final FontAwesomeIconView viewIcon = new FontAwesomeIconView(FontAwesomeIcon.EYE);

            {
                editIcon.setStyleClass("action-icon");
                deleteIcon.setStyleClass("action-icon");
                viewIcon.setStyleClass("action-icon");

                editIcon.setOnMouseClicked(event -> handleEditAction( VoitureDao.getVoitureDetails(getTableView().getItems().get(getIndex()).getIdVeh() ) ))   ;
                deleteIcon.setOnMouseClicked(event -> handleDeleteAction(getTableView().getItems().get(getIndex())));
                viewIcon.setOnMouseClicked(event -> {
                    try {
                        handleViewDetails(event);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });

                editIcon.setSize("1.8em");
                deleteIcon.setSize("1.8em");
                viewIcon.setSize("1.8em");
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox actions = new HBox(10, editIcon, deleteIcon, viewIcon);
                    actions.setAlignment(Pos.CENTER);
                    setGraphic(actions);
                }
            }
        });
    }

    private void handleEditAction(Vehicule vehicle) {
        try {
            // Load the FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Voiture/voiture-add-view.fxml"));
            Scene modalScene = new Scene(loader.load(), 930, 500);

            // Get the controller
            VoitureAddController controller = loader.getController();
            controller.setStage((Stage) clientsTable.getScene().getWindow());
            controller.setEditMode(vehicle); // Pass the vehicle to edit

            // Create a modal window
            Stage modalStage = new Stage();
            modalStage.initModality(Modality.APPLICATION_MODAL);
            modalStage.initStyle(StageStyle.UNDECORATED);
            modalStage.setScene(modalScene);

            controller.setStage(modalStage); // Corrige l'affectation du stage


            // Set the blur and overlay
            Scene mainScene = clientsTable.getScene();
            HBox root = (HBox) mainScene.getRoot();
            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);
            GaussianBlur blur = new GaussianBlur(10);
            root.getChildren().add(overlay);
            root.setEffect(blur);

            modalStage.setOnHidden(e -> {
                root.getChildren().remove(overlay);
                root.setEffect(null);
                loadData(); // Reload data to see the changes
            });

            modalStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void handleDeleteAction(Vehicule voiture) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Êtes-vous sûr de vouloir supprimer ce véhicule ?");
        alert.setContentText("Cette action supprimera définitivement le véhicule sélectionné.");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            VoitureDao.deleteVehicle(voiture.getIdVeh());

            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succes");
            alert.setHeaderText(null);
            alert.setContentText("Le véhicule a été supprimé avec succès.");
            alert.showAndWait();
        }



        loadData();
    }

    @FXML
    public void handleViewDetails(MouseEvent event) throws IOException {

        Vehicule selectedVehicule = clientsTable.getSelectionModel().getSelectedItem();
        if (selectedVehicule == null) return;


        Vehicule detailedVehicule = VoitureDao.getVoitureDetails(selectedVehicule.getIdVeh());


        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Voiture/voiture-details-view.fxml"));
        Scene modalScene = new Scene(loader.load(), 800, 690);


        VoitureDetailsController controller = loader.getController();
        controller.setVoitureDetails(detailedVehicule);


        Stage modalStage = new Stage();
        modalStage.initModality(Modality.APPLICATION_MODAL);
        modalStage.initStyle(StageStyle.UNDECORATED);
        modalStage.setScene(modalScene);


        Scene mainScene = clientsTable.getScene();
        HBox root = (HBox) mainScene.getRoot();


        Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
        overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
        overlay.setManaged(false);
        overlay.setMouseTransparent(true);


        GaussianBlur blur = new GaussianBlur(10);
        root.getChildren().add(overlay);
        root.setEffect(blur);


        modalStage.setOnHidden(e -> {
            root.getChildren().remove(overlay);
            root.setEffect(null);
        });


        modalStage.showAndWait();
    }



    private void updateStatistics() {
        int total = vehiculeList.size();
        long inMaintenance = vehiculeList.stream().filter(v -> "En Maintenance".equals(v.getStatutVeh())).count();
        long inUse = vehiculeList.stream().filter(v -> "En Location".equals(v.getStatutVeh())).count();
        long available = vehiculeList.stream().filter(v -> "Disponible".equals(v.getStatutVeh())).count();

        totalVoitureLabel.setText(String.valueOf(total));
        vehiclesInMaintenanceLabel.setText(String.valueOf(inMaintenance));
        vehiclesInUseLabel.setText(String.valueOf(inUse));
        availableVehiclesLabel.setText(String.valueOf(available));
    }

    @FXML
    private void handleAddVehicle() {
        try {
            // Charger le FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/location/view/Voiture/voiture-add-view.fxml"));
            VBox page = loader.load();

            // Créer la fenêtre de dialogue
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Ajouter un véhicule");
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.initStyle(StageStyle.UNDECORATED);

            // Configurer la scène
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Obtenir le contrôleur et définir le stage
            VoitureAddController controller = loader.getController();
            controller.setStage(dialogStage);

            // Ajouter l'effet de flou sur la fenêtre principale
            Scene mainScene = clientsTable.getScene();
            HBox root = (HBox) mainScene.getRoot();

            // Créer l'overlay
            Rectangle overlay = new Rectangle(mainScene.getWidth(), mainScene.getHeight());
            overlay.setFill(javafx.scene.paint.Color.color(0, 0, 0, 0.5));
            overlay.setManaged(false);
            overlay.setMouseTransparent(true);

            // Appliquer le flou
            GaussianBlur blur = new GaussianBlur(10);
            root.getChildren().add(overlay);
            root.setEffect(blur);

            // Restaurer l'état normal lors de la fermeture
            dialogStage.setOnHidden(e -> {
                root.getChildren().remove(overlay);
                root.setEffect(null);

                // Si l'utilisateur a cliqué sur Enregistrer
                if (controller.isSaveClicked()) {
                    Vehicule newVehicule = controller.getNewVehicle();
                    VoitureDao.addVehicle(newVehicule);
                    loadData();
                }
            });

            // Afficher la fenêtre de dialogue
            dialogStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Erreur lors de l'ouverture du formulaire d'ajout de véhicule.");
            alert.showAndWait();
        }
    }


    @FXML
    private void handleDashboard(MouseEvent event) {
        Switch.changeScene(event, "view/Dashboard/dashboard-view.fxml");
    }

    @FXML
    private void handleClient(MouseEvent event) {
        Switch.changeScene(event, "view/Client/client-view.fxml");
    }

    @FXML
    private void handleLocations(MouseEvent event) {
        Switch.changeScene(event, "view/Location/location-view.fxml");
    }

    @FXML
    private void handlePaiements(MouseEvent event) {
        Switch.changeScene(event, "view/Paiement/paiement-view.fxml");
    }
    public void handleEmploye(MouseEvent event) {
        if (HelloApplication.permission == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Accès refusé");
            alert.setHeaderText("Accès refusé");
            alert.setContentText("Vous devez avoir un compte admin pour acceder au menu Employé");
            alert.showAndWait();
            return;
        }
        Switch.changeScene(event, "view/Employe/employe-view.fxml");
    }
    @FXML
    private void handleVehicules(MouseEvent event) {
        loadData();
    }

    @FXML
    private void handleSearch() {

        String searchTerm = searchField.getText().toLowerCase();
        String filterBy = filterComboBox.getSelectionModel().getSelectedItem();

        if (searchTerm.isEmpty()) {
            loadData();
            return;
        }

        ObservableList<Vehicule> filteredVehicules = vehiculeList.filtered(vehicule -> {
            switch (filterBy) {
                case "Marque":
                    return vehicule.getMarqueVeh().toLowerCase().contains(searchTerm);
                case "Modèle":
                    return vehicule.getModeleVeh().toLowerCase().contains(searchTerm);
                case "Énergie":
                    return vehicule.getEnergieVeh().toLowerCase().contains(searchTerm);
                default:
                    return false;
            }
        });

        clientsTable.setItems(filteredVehicules);
    }

    @FXML
    private void handleFilterChange() {
        handleSearch();
    }

    @FXML
    private void filterTotalVoitures() {
        clientsTable.setItems(vehiculeList);
        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }

    @FXML
    private void filterVoituresEnMaintenance() {
        ObservableList<Vehicule> filteredVehicules = vehiculeList.filtered(vehicule ->
                "En Maintenance".equals(vehicule.getStatutVeh())
        );

        clientsTable.setItems(filteredVehicules);
        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }

    @FXML
    private void filterVoituresDisponibles() {
        ObservableList<Vehicule> filteredVehicules = vehiculeList.filtered(vehicule ->
                "Disponible".equals(vehicule.getStatutVeh())
        );

        clientsTable.setItems(filteredVehicules);
        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }

    @FXML
    private void filterVoituresEnLocation() {
        ObservableList<Vehicule> filteredVehicules = vehiculeList.filtered(vehicule ->
                "En Location".equals(vehicule.getStatutVeh())
        );

        clientsTable.setItems(filteredVehicules);
        clientsTable.getColumns().get(7).setVisible(false);
        clientsTable.getColumns().get(7).setVisible(true);
    }

}
