module org.example.location {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires  de.jensd.fx.glyphs.commons;
    requires de.jensd.fx.glyphs.fontawesome;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires eu.hansolo.tilesfx;
    requires java.sql;

    opens org.example.location to javafx.fxml;
    exports org.example.location;
    exports org.example.location.controllers;
    opens org.example.location.controllers to javafx.fxml;
    exports org.example.location.models;
    opens org.example.location.models to javafx.fxml;
    exports org.example.location.controllers.Client;
    opens org.example.location.controllers.Client to javafx.fxml;
    exports org.example.location.controllers.Location;
    opens org.example.location.controllers.Location to javafx.fxml;
    exports org.example.location.controllers.Paiement;
    opens org.example.location.controllers.Paiement to javafx.fxml;
    exports org.example.location.controllers.Voiture;
    opens org.example.location.controllers.Voiture to javafx.fxml;
    exports org.example.location.controllers.Employe;
    opens org.example.location.controllers.Employe to javafx.fxml;
    exports org.example.location.controllers.Agence;
    opens org.example.location.controllers.Agence to javafx.fxml;
    exports org.example.location.controllers.Dashboard;
    opens org.example.location.controllers.Dashboard to javafx.fxml;

    requires org.apache.pdfbox; // iText core library
}